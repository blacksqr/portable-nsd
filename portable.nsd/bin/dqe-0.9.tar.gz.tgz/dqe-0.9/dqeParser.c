#include "dqe.h"
#include "dqeParser.h"

static void Parser(Ns_DString *out, char *in) /* {{{ */
{
    Tcl_Obj *obj[2],*or,*ore;
    Tcl_DString ds;
    Ns_Conn *c;
    Ns_Time time0,time1;
    Tcl_Interp *i;
    int j,llen,rlen;
    char *re;
    
    c=Ns_TclGetConn(NULL);
    i=Ns_GetConnInterp(c);

    if ((obj[0]=Tcl_NewStringObj(TCL_PROC_NAME,-1))==NULL)
        return;
    
    Tcl_IncrRefCount(obj[0]);
    Tcl_DStringInit(&ds);
    Tcl_ExternalToUtfDString(NULL,in,-1,&ds);

    Ns_GetTime(&time0);

    if ((obj[1]=Tcl_NewStringObj(Tcl_DStringValue(&ds),Tcl_DStringLength(&ds)))!=NULL)
    {
        Tcl_IncrRefCount(obj[1]);
        if (Tcl_EvalObjv(i,2,obj,0)==TCL_OK) 
        {
            if ((or=Tcl_GetObjResult(i))!=NULL) 
            {
                if (Tcl_ListObjLength(i,or,&llen)==TCL_OK)
                {
                    for (j=0;j<llen;j++)
                    {
                        if (Tcl_ListObjIndex(i,or,j,&ore)==TCL_OK)
                        {
                            re=Tcl_GetStringFromObj(ore,&rlen);
                            Tcl_DStringFree(&ds);
                            Tcl_UtfToExternalDString(NULL,re,rlen,&ds);
                            if (rlen>0)
                            {
                                Ns_DStringNAppend(out,Tcl_DStringValue(&ds),Tcl_DStringLength(&ds));
                                Ns_DStringNAppend(out,"\0",1);
                            }
                        }
                    }
                }
            }
        }
        else
        {
            Ns_Log(Bug,"Error while parsing dq-e page:\n%s",Tcl_GetStringResult(i));
        }
        Tcl_DecrRefCount(obj[1]);
    }
    /* only for new dqe parser testing :-)
    Ns_GetTime(&time1);
    Ns_Log(Debug,"DQE parser time: %d",(time1.sec-time0.sec)*1000000+(time1.usec-time0.usec));
    */
    
    Tcl_DStringFree(&ds);
    
    Tcl_DecrRefCount(obj[0]);
    
}
/* }}} */
static int dqe_Parser_TclInit(Tcl_Interp *interp, ClientData oc) /* {{{ */
{
    // Tcl_CreateObjCommand(interp,"dqe_parsecomment",(Tcl_ObjCmdProc *) ParseDqeCmd,(ClientData) oc,NULL);
    return TCL_OK;
}
/* }}} */
void dqe_Parser_Init(char *server, char *module) /* {{{ */
{
    Ns_Log(Notice,"%s::Parser loaded",server);
    Ns_AdpRegisterParser("dq-e",Parser);
    Ns_TclInitInterps(server,(Ns_TclInterpInitProc *) dqe_Parser_TclInit,NULL);
}
/* }}} */
    
