#ifndef DQESTAT_H
#define DQESTAT_H 1

#include "dqe.h"

struct dqe_Stat_OpCtx {
    int dummy;
};

#endif
