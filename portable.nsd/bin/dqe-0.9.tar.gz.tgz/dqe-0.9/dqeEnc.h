#ifndef DQEENC_H
#define DQEENC_H 1

#include "dqe.h"

struct dqe_Enc_OpCtx {
    char *e_Encoding;
};

struct dqe_Enc_Tls {
    char e_SsnEnc[64];
};

#endif
