#include "dqe.h"
#include "dqeChan.h"

int DqeChan_Detach(Tcl_Interp *interp, char *chstr) /* {{{ */
{
    int *fdptr;
    Tcl_Channel channel;
    if ((strncmp(chstr,"file",4)!=0)&&(strncmp(chstr,"sock",4)!=0))
    {
        Tcl_AppendResult(interp,chstr," is not a valid file/socket handler",NULL);
        return TCL_ERROR;
    }
    if ((channel=Tcl_GetChannel(interp,chstr,NULL))!=NULL)
    {
        fdptr=((((int **)channel)[1])+1); // this is very hardcoded low-level :(
        *fdptr=-1;
        Tcl_UnregisterChannel(interp,channel);
        return TCL_OK;
    }  else  {
        Tcl_AppendResult(interp,chstr," is not a registered channel handler",NULL);
        return TCL_ERROR;
    }
}
/* }}} */
int DqeChan_Attach(Tcl_Interp *interp, char *chstr) /* {{{ */
{
    Tcl_Channel channel;
    int fd, result=TCL_OK;
    if (strncmp(chstr,"sock",4)==0)
    {
        fd=atoi(chstr+4);
        if ((channel=Tcl_MakeTcpClientChannel((ClientData) fd))!=NULL)
            Tcl_RegisterChannel(interp,channel);
        else
            result=TCL_ERROR;
    }
    else if (strncmp(chstr,"file",4)==0)
    {
        int md=TCL_READABLE|TCL_WRITABLE;
        fd=atoi(chstr+4);
        if ((channel=Tcl_MakeFileChannel((ClientData) fd,md))!=NULL)
        {
            Tcl_RegisterChannel(interp,channel);
        }
        else
            result=TCL_ERROR;
    }
    else
    {
        Tcl_AppendResult(interp,chstr," is not a valid file/socket handler",NULL);
        result=TCL_ERROR;
    }
    return result;
}
/* }}} */
/* commands {{{ */
enum {
    C_DETACH,
    C_ATTACH,
    C_MAX
};
static char *ds_idx[] = {
    "detach",
    "attach",
    NULL
};
/* }}} */
static int ChanCmd(struct dqe_Chan_OpCtx *oc, Tcl_Interp *interp, int objc, Tcl_Obj *CONST objv[]) /* {{{ */
{
    int cmd;
    
    if (objc!=3)
    {
        Tcl_WrongNumArgs(interp,1,objv,"command channel");
        return TCL_ERROR;
    }
    if (Tcl_GetIndexFromObj(interp,objv[1],ds_idx,"command",0,&cmd)!=TCL_OK)
        return TCL_ERROR;
    
    switch (cmd)
    {
        case C_DETACH:
            if (DqeChan_Detach(interp,Tcl_GetString(objv[2]))!=TCL_OK)
            {
                return(TCL_ERROR);
            }
            break;
        case C_ATTACH:
            if (DqeChan_Attach(interp,Tcl_GetString(objv[2]))!=TCL_OK)
            {
                return(TCL_ERROR);
            }
            break;
    }
    return TCL_OK;
}
/* }}} */
static int dqe_Chan_TclInit(Tcl_Interp *interp, ClientData oc) /* {{{ */
{
    Tcl_CreateObjCommand(interp,"dqe_channel",(Tcl_ObjCmdProc *) ChanCmd,(ClientData) oc,NULL);
    return TCL_OK;
}
/* }}} */
void dqe_Chan_Init(char *server, char *module) /* {{{ */
{
    Ns_TclInitInterps(server,(Ns_TclInterpInitProc *) dqe_Chan_TclInit,NULL);
    Ns_Log(Notice,"%s::channel sharing (8.3 version) loaded",server);
}
/* }}} */

