#include "dqe.h"
#include "dqePcount.h"

/* commands {{{ */
enum {
    C_BENCH,
    C_STATS,
    C_CLEAR,
    C_DUMMY
};
static char *c_idx[] = {
    "bench",
    "stats",
    "clear",
    NULL
};
/* }}} */
static void freehv(struct dqe_Pcount_Value *v) /* {{{ */
{
    Ns_Free(v);
}
/* }}} */
static struct dqe_Pcount_Value * gethv(struct dqe_Pcount_OpCtx *oc, Ns_Conn *conn) /* {{{ */
{
    Ns_Entry *he;
    Ns_DString ds;
    Ns_Set *set;
    char *str;
    int new;
    struct dqe_Pcount_Value *hv;

    /* key creation */
    Ns_DStringInit(&ds);
    if ( (set=Ns_ConnHeaders(conn)) != NULL )
        if ((str=Ns_SetIGet(set,"host"))!=NULL)
        {
            if (strncasecmp(str,"www.",4)==0)
                str+=4;
            Ns_DStringAppend(&ds,str);
        }
    Ns_DStringAppend(&ds,":");
    Ns_DStringAppend(&ds,conn->request->url);
    Ns_DStringAppend(&ds,"\0");
    /* hashtable entries */
    he=Ns_CacheCreateEntry(oc->cache,Ns_DStringValue(&ds),&new);
    if (new)
    {
        hv=Ns_Malloc(sizeof(struct dqe_Pcount_Value));
        hv->timeid=0;
        hv->ntimes=0;
        hv->ntimed=0;
        hv->totaltime=0;
        Ns_CacheSetValueSz(he,hv,sizeof(struct dqe_Pcount_Value));
    }
    else
        hv=Ns_CacheGetValue(he);
    
    Ns_DStringFree(&ds);
    return(hv);
}
/* }}} */
static void bench_begin(struct dqe_Pcount_OpCtx *oc, Ns_Conn *conn) /* {{{ */
{
    struct dqe_Pcount_Value *hv;

    Ns_MutexLock(&oc->mutex);
    hv=gethv(oc,conn);
    if ((hv->timeid==0))
    {
        Ns_GetTime(&hv->starttime);
        hv->timeid=Ns_ThreadId();
    }
    Ns_MutexUnlock(&oc->mutex);
}
/* }}} */
static int dqe_Pcount_Filter(struct dqe_Pcount_OpCtx *oc, Ns_Conn *conn, int why) /* {{{ */
{
    Ns_Time time;
    struct dqe_Pcount_Value *hv;
    unsigned long diff;
    
    Ns_MutexLock(&oc->mutex);
    hv=gethv(oc,conn);
    if (why && NS_FILTER_TRACE)
    {
        hv->ntimes++;
        if (hv->timeid==Ns_ThreadId())
        {
            Ns_GetTime(&time);
    
            diff=(time.sec-hv->starttime.sec)*1000000+(time.usec-hv->starttime.usec);
    
            hv->totaltime+=(diff+5)/10;
            hv->ntimed++;
    
            hv->timeid=0;
        }
    }
    Ns_MutexUnlock(&oc->mutex);
    return NS_OK;
}
/* }}} */
static int dqe_PcountCmd(struct dqe_Pcount_OpCtx *oc, Tcl_Interp *interp, int objc, Tcl_Obj *CONST objv[]) /* {{{ */
{
    int cmd;
    char *nam;
    Tcl_HashEntry *he;
    struct ds_PcountData *sd;
    if (objc<2)
    {
        Tcl_WrongNumArgs(interp,1,objv,"subcommand ?args?");
        return TCL_ERROR;
    }
    if (Tcl_GetIndexFromObj(interp,objv[1],c_idx,"option",0,&cmd)!=TCL_OK)
        return TCL_ERROR;
    
    switch (cmd)
    {
        case C_BENCH: /* {{{ */
            if (objc!=2)
            {
                Tcl_WrongNumArgs(interp,2,objv,"");
                return TCL_ERROR;
            }
            bench_begin(oc, Ns_GetConn());
            return TCL_OK;
        /* }}} */
        case C_STATS: /* {{{ */
        {
            Tcl_Obj *listobj,*elistobj,*elemobj;
            // Tcl_HashEntry *he;
            // Tcl_HashSearch hsrch;
            Ns_Entry *he;
            Ns_CacheSearch hsrch;
            struct dqe_Pcount_Value *hv;
            if (objc!=2)
            {
                Tcl_WrongNumArgs(interp,2,objv,"");
                return TCL_ERROR;
            }
            if ((listobj=Tcl_NewListObj(0,NULL))!=NULL)
            {
                Ns_MutexLock(&oc->mutex);
                for (he=Ns_CacheFirstEntry(oc->cache,&hsrch);he;he=Ns_CacheNextEntry(&hsrch))
                {
                    hv=Ns_CacheGetValue(he);
                    if ((elistobj=Tcl_NewListObj(0,NULL))!=NULL)
                    {
                        Tcl_ListObjAppendElement(interp,elistobj,Tcl_NewStringObj(Ns_CacheKey(he),-1));
                        Tcl_ListObjAppendElement(interp,elistobj,Tcl_NewLongObj(hv->ntimes));
                        Tcl_ListObjAppendElement(interp,elistobj,Tcl_NewLongObj(hv->totaltime));
                        Tcl_ListObjAppendElement(interp,elistobj,Tcl_NewLongObj(hv->ntimed));
                        if (hv->ntimed>0)
                            Tcl_ListObjAppendElement(interp,elistobj,Tcl_NewDoubleObj(((double) hv->totaltime)/((double) hv->ntimed)));
                        else
                            Tcl_ListObjAppendElement(interp,elistobj,Tcl_NewDoubleObj(0.0));
                        Tcl_ListObjAppendElement(interp,listobj,elistobj);
                    }
                }
                Ns_MutexUnlock(&oc->mutex);
                Tcl_SetObjResult(interp,listobj);
            }
            return TCL_OK;
        } /* }}} */
        default:
            Tcl_SetResult(interp,"Not implemented",NULL);
            return TCL_ERROR;
    }
    return TCL_OK;
}
/* }}} */
static int dqe_Pcount_TclInit(Tcl_Interp *interp, struct dqe_Pcount_OpCtx *oc) /* {{{ */
{
    Tcl_CreateObjCommand(interp,"dqe_pcount",(Tcl_ObjCmdProc *) dqe_PcountCmd,oc,NULL);
    return NS_OK;
}
/* }}} */
void dqe_Pcount_Init(char *server, char *module) /* {{{ */
{
    int maxsize=24,enabled=0;
    struct dqe_Pcount_OpCtx *oc;
    char *path;
    
    if ((oc=Ns_Malloc(sizeof(struct dqe_Pcount_OpCtx)))!=NULL)
    {
        if ((path=Ns_ConfigGetPath(server,"dqe","pcount",NULL))!=NULL)
        {
            if (Ns_ConfigGetInt(path,"buffersize",&maxsize)!=NS_TRUE)
                maxsize=1024*1024;
            if (Ns_ConfigGetBool(path,"enabled",&enabled)!=NS_TRUE)
                enabled=0;
        }
        if (enabled)
        {
            oc->cache=Ns_CacheCreateSz("Pcount",TCL_STRING_KEYS,maxsize,(Ns_Callback *) freehv);
            Ns_TclInitInterps(server,(Ns_TclInterpInitProc *) dqe_Pcount_TclInit,oc);
            Ns_RegisterFilter(server,"GET","*",(Ns_FilterProc *) dqe_Pcount_Filter,NS_FILTER_TRACE,oc);
            Ns_RegisterFilter(server,"HEAD","*",(Ns_FilterProc *) dqe_Pcount_Filter,NS_FILTER_TRACE,oc);
            Ns_RegisterFilter(server,"POST","*",(Ns_FilterProc *) dqe_Pcount_Filter,NS_FILTER_TRACE,oc);
            Ns_MutexInit(&oc->mutex);
            Ns_Log(Notice,"%s::Pcount loaded (buffer size is %d)",server,maxsize);
        }
        else
        {
            Ns_Log(Notice,"%s::Pcount not enabled",server);
        }
    }
}
/* }}} */

