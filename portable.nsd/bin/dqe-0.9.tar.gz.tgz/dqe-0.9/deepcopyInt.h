#ifndef DEEPCOPYINT_H
#define DEEPCOPYINT_H 1

#define DCO_STRING      1
#define DCO_INTEGER     2
#define DCO_LONG        3
#define DCO_DOUBLE      4
#define DCO_LIST        5

#define dc_Malloc       Ns_Malloc
#define dc_Free         Ns_Free

/* objhead */
struct dcObjHead {
    short type;
    unsigned long size;         // including dcObjHead
};

/* int object */
struct dcIntObj {
    struct dcObjHead head;
    int value;
};

static struct dcObjHead *int_GetTclObj(Tcl_Obj *to);
Tcl_Obj *int_NewTclObj(struct dcObjHead *o);
static void int_Free(struct dcObjHead *o);

/* long object */
struct dcLongObj {
    struct dcObjHead head;
    long value;
};

static struct dcObjHead *long_GetTclObj(Tcl_Obj *to);
Tcl_Obj *long_NewTclObj(struct dcObjHead *o);
static void long_Free(struct dcObjHead *o);

/* double object */
struct dcDoubleObj {
    struct dcObjHead head;
    double value;
};

static struct dcObjHead *double_GetTclObj(Tcl_Obj *to);
Tcl_Obj *double_NewTclObj(struct dcObjHead *o);
static void double_Free(struct dcObjHead *o);

/* string object */
struct dcStrObj {
    struct dcObjHead head;
    char string[1];
};

static struct dcObjHead *str_GetTclObj(Tcl_Obj *to);
Tcl_Obj *str_NewTclObj(struct dcObjHead *o);
static void str_Free(struct dcObjHead *o);

/* list object */
struct dcListObj {
    struct dcObjHead head;
    int nelem;
    struct dcObjHead *list[1];
};

static struct dcObjHead *list_GetTclObj(Tcl_Obj *to);
Tcl_Obj *list_NewTclObj(struct dcObjHead *o);
static void list_Free(struct dcObjHead *o);

#endif

