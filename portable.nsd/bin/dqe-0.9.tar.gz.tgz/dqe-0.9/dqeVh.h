#ifndef DQEVH_H
#define DQEVH_H 1

#include "dqe.h"

#define DQEVH_TCLCMD            "nssmartvh::name"

/* OpCtx */
struct dqe_Vh_OpCtx {
    int globaldomaincachesize;
    Ns_Mutex mutex;
    Ns_Tls tlsdata;
    Ns_Cache *globaldomaincache;
    char *pageroot;
    char *servername;
    char *hostname;
    void *domainplist;
    void *urlplist;
    void *filterplist;
};

/* Thread Local Storage */

struct dqe_Vh_Tls {
    int initialized;
    char hostname[DQEVH_HOST_SIZE];
    struct dqe_Vh_DomainEntry *conndomain;
    char locationbuf[DQEVH_HOST_SIZE+32];
};

struct dqe_Vh_DomainEntry {
    int refcount;
    char path[DQEVH_PATH_SIZE];
};

/* Tls functions */
static void tls_cleanup(struct dqe_Vh_Tls *tls);
static struct dqe_Vh_Tls *tls_get(struct dqe_Vh_OpCtx *oc, int allownew);
static void tls_free(struct dqe_Vh_Tls *tls);

/* domain functions */

static struct dqe_Vh_DomainEntry *dom_init(struct dqe_Vh_OpCtx *oc, char *domain);
static void dom_flush(struct dqe_Vh_DomainEntry *ent);

/* */

struct dqe_Vh_Pnode {
    struct dqe_Vh_Pnode *next;
    short priority;
    DqeVh_Callback *callback;
    void *clientdata;
};

struct dqe_Vh_Plist {
    struct dqe_Vh_Pnode *first;
    Ns_Mutex mutex;
    struct dqe_Vh_Pnode guard0;
    struct dqe_Vh_Pnode guard1;
};

static struct dqe_Vh_Plist *pl_create(void);
static void pl_add(struct dqe_Vh_Plist *pl, short pri, DqeVh_Callback *cb, void *cd);
static void pl_delete(struct dqe_Vh_Plist *pl);
static int pl_call(struct dqe_Vh_Plist *pl, void *arg);

#endif
