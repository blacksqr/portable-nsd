#ifndef DQEVHSTD_H
#define DQEVHSTD_H 1

struct dqe_VhStd_DHC {
    int refcount;
    time_t file_mtime;
    off_t file_size;
    Ns_Set *set_match;
};

struct dqe_VhStd_FHC {
    int refcount;
    time_t file_mtime;
    off_t file_size;
    Ns_Set *set_match;
};

struct dqe_VhStd_OpCtx {
    char *servername;
    char *filtersfile;
    char *rewritesfile;
    size_t helpercachesize;
    Ns_Cache *domainhelpercache;
    Ns_Cache *filterhelpercache;
    char *vhostsfile;
    char *vhostsfilename;
    time_t vhosts_mtime;
    off_t vhosts_size;
};


#endif
