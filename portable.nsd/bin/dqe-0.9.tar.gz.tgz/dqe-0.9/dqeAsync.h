#ifndef DQEASYNC_H
#define DQEASYNC_H 1

#include "dqe.h"

typedef struct dqe_AsyncDataCmd {
    struct dqe_AsyncDataCmd *dac_Prev;
    char dac_Data[1];
} dqe_AsyncDataCmd;
typedef struct dqe_AsyncData {
    char *da_Cmd;
    dqe_AsyncDataCmd *da_Data;
    Ns_Mutex da_Mutex;
    Tcl_Interp *da_Interp;
    Tcl_AsyncHandler da_AsyncHandler;
} dqe_AsyncData;

struct dqe_Async_OpCtx {
    int dummy;
};

#endif
