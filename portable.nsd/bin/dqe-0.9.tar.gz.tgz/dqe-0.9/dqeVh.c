#include "dqe.h"
#include "dqeVh.h"
#include "ns.h"
#include "../aolserver/nsd/nsd.h"

#define CONN_CLOSED(conn)               ((conn)->flags & NS_CONN_CLOSED)
#define CONN_DRVPROC(conn,proc)         (((Conn *) conn)->drvPtr->proc)
#define CONN_DRVCALL(conn,proc,default) \
        ((CONN_DRVPROC(conn,proc)) ? \
        ((*(CONN_DRVPROC(conn,proc)))(((Conn *) conn)->drvData)) : \
        (default))
                                
static int nsss_id=-1;

void *DqeVh_Ctx(char *server) /* {{{ */
{
    return(Ns_ServerSpecificGet(server,nsss_id));
}
/* }}} */
int DqeVh_Url2File(void *ctx, Ns_DString *ds, char *domain, char *url) /* {{{ */
{
    struct dqe_Vh_OpCtx *oc=ctx;
    struct dqe_Vh_DomainEntry *d;
    DqeVh_UrlQuery uq;

    /* domain initialization */
    Ns_CacheLock(oc->globaldomaincache);
    d=dom_init(oc,domain);
    strcpy(uq.pageroot,d->path);
    dom_flush(d);
    Ns_CacheUnlock(oc->globaldomaincache);
    uq.domain=domain;
    if (strlen(domain)>4)
    {
        if (!strncasecmp(domain,"www.",4))
            uq.domainnowww=domain+4;
        else
            uq.domainnowww=domain;
    }
    else
        uq.domainnowww=domain;
    uq.url=url;
    snprintf(uq.filename,DQEVH_PATH_SIZE,"%s%s",uq.pageroot,url);
    pl_call(oc->urlplist,&uq);
    Ns_DStringAppend(ds,uq.filename);
    while (ds->length > 0 && ds->string[ds->length-1] == '/') {
	    Ns_DStringTrunc(ds, ds->length-1);
    }
    return NS_OK;
}
/* }}} */
static int DqeVh_Url2FileDom(void *ctx, Ns_DString *ds, char *domain, struct dqe_Vh_DomainEntry *dom, char *url) /* {{{ */
{
    struct dqe_Vh_OpCtx *oc=ctx;
    DqeVh_UrlQuery uq;

    /* domain initialization */
    strcpy(uq.pageroot,dom->path);
    uq.domain=domain;
    uq.domainnowww=domain;
    uq.url=url;
    snprintf(uq.filename,DQEVH_PATH_SIZE,"%s%s",uq.pageroot,url);
    pl_call(oc->urlplist,&uq);
    Ns_DStringAppend(ds,uq.filename);
    while (ds->length > 0 && ds->string[ds->length-1] == '/') {
	    Ns_DStringTrunc(ds, ds->length-1);
    }
    return NS_OK;
}
/* }}} */
void DqeVh_DomainAddHandler(void *ctx, short priority, DqeVh_Callback *callback, ClientData clientdata) /* {{{ */
{
    struct dqe_Vh_OpCtx *oc=ctx;
    pl_add(oc->domainplist,priority,callback,clientdata);
}
/* }}} */
void DqeVh_UrlAddHandler(void *ctx, short priority, DqeVh_Callback *callback, ClientData clientdata) /* {{{ */
{
    struct dqe_Vh_OpCtx *oc=ctx;
    pl_add(oc->urlplist,priority,callback,clientdata);
}
/* }}} */
void DqeVh_FilterAddHandler(void *ctx, short priority, DqeVh_Callback *callback, ClientData clientdata) /* {{{ */
{
    struct dqe_Vh_OpCtx *oc=ctx;
    pl_add(oc->filterplist,priority,callback,clientdata);
}
/* }}} */

/* internal functions */

/* priority lists */
static struct dqe_Vh_Plist *pl_create(void) /* {{{ */
{
    struct dqe_Vh_Plist *rc;
    rc=Ns_Malloc(sizeof(struct dqe_Vh_Plist));
    Ns_MutexInit(&rc->mutex);
    rc->first=&rc->guard0;
    rc->guard0.next=&rc->guard1;
    rc->guard0.priority=0x7FFF;
    rc->guard0.callback=NULL;
    rc->guard0.clientdata=NULL;
    rc->guard1.next=NULL;
    rc->guard1.priority=0x8000;
    rc->guard1.callback=NULL;
    rc->guard1.clientdata=NULL;
    return(rc);
}
/* }}} */
static void pl_add(struct dqe_Vh_Plist *pl, short pri, DqeVh_Callback *cb, void *cd) /* {{{ */
{
    struct dqe_Vh_Pnode *n,*ip,*ipp;
    Ns_MutexLock(&pl->mutex);
    if ((n=Ns_Malloc(sizeof(struct dqe_Vh_Pnode)))!=NULL)
    {
        ipp=&pl->guard0;
        while ((ip=ipp->next)!=NULL)
        {
            if (ip->priority<=pri)
                break;
            ipp=ip;
        }
        n->next=ipp->next;
        ipp->next=n;
        n->priority=pri;
        n->callback=cb;
        n->clientdata=cd;
    }
    Ns_MutexUnlock(&pl->mutex);
}
/* }}} */
static void pl_delete(struct dqe_Vh_Plist *pl) /* {{{ */
{
    struct dqe_Vh_Pnode *n,*nn;
    n=pl->first->next;
    while ((nn=n->next)!=NULL)
    {
        Ns_Free(n);
        n=nn;
    }
    Ns_Free(pl);
}
/* }}} */
static int pl_call(struct dqe_Vh_Plist *pl, void *arg) /* {{{ */
{
    struct dqe_Vh_Pnode *pn;
    int rc;
    Ns_MutexLock(&pl->mutex);
    for (pn=pl->first->next;pn->next;pn=pn->next)
    {
        rc=pn->callback(pn->clientdata, arg);
        if (rc==DQEVH_CB_BREAK)
            break;
    }
    Ns_MutexUnlock(&pl->mutex);
    return(rc);
}
/* }}} */

/* tls */
static void tls_cleanup(struct dqe_Vh_Tls *tls) /* {{{ */
{
    tls->initialized=0;
}
/* }}} */
static struct dqe_Vh_Tls *tls_get(struct dqe_Vh_OpCtx *oc,int allownew) /* {{{ */
{
    char buf[1024];
    struct dqe_Vh_Tls *rc;
    rc=Ns_TlsGet(&oc->tlsdata);
    if (!rc)
    {
        if (allownew)
        {
            rc=Ns_Malloc(sizeof(struct dqe_Vh_Tls));
            tls_cleanup(rc);
        }
    }
    else
    {
        tls_cleanup(rc);
    }
    if (rc)
    {
        Ns_TlsSet(&oc->tlsdata,rc);
    }
    return rc;
}
/* }}} */
static void tls_free(struct dqe_Vh_Tls *tls) /* {{{ */
{
    if (tls)
    {
        Ns_Free((void *) tls);
    }
}
/* }}} */
static struct dqe_Vh_Tls *tls_initconn(struct dqe_Vh_OpCtx *oc, Ns_Conn *conn) /* {{{ */
{
    struct dqe_Vh_Tls *tls;
    Ns_Set *headers;
    char *host,*proto,*loc;
    int hashost=0;
    struct dqe_Vh_DomainEntry *dom;
    
    tls=tls_get(oc,1);
    if (!tls->initialized)
    {
        if (conn)
        {
            if ((headers=Ns_ConnHeaders(conn))!=NULL)
            {
                if ((host=Ns_SetIGet(headers,"host"))!=NULL)
                {
                    if (strlen(host)>4)
                    {
                        if (!strncasecmp("www.",host,4))
                            host+=4;
                    }
                    strncpy(tls->hostname,host,sizeof(tls->hostname));
                    hashost=1;
                }
            }
        }
        proto=CONN_DRVCALL(conn, locationProc, NULL);
        if (!hashost)
        {
            if ((loc=strchr(proto,':'))!=NULL)
            {
                loc+=3;
                strncpy(tls->hostname,loc,sizeof(tls->hostname));
            }
            else
            {
                strncpy(tls->hostname,oc->servername,sizeof(tls->hostname));
            }
        }
        Ns_CacheLock(oc->globaldomaincache);
        dom=dom_init(oc,tls->hostname);
        Ns_CacheUnlock(oc->globaldomaincache);
        strncpy(tls->locationbuf,proto,32);
        if ((proto=strchr(tls->locationbuf,':'))!=NULL)
            *proto=0;
        else
            proto=tls->locationbuf+4;
        strcpy(proto,"://www.");
        proto+=7;
        proto=tls->locationbuf+strlen(tls->locationbuf);
        strncpy(proto,tls->hostname,sizeof(tls->locationbuf)-(proto-tls->locationbuf));
        tls->conndomain=dom;
        tls->initialized=1;
    }
    return(tls);
}
/* }}} */

/* domains */
static struct dqe_Vh_DomainEntry *dom_init(struct dqe_Vh_OpCtx *oc, char *domain) /* {{{ */
{
    int new;
    struct dqe_Vh_DomainEntry *rc=NULL;

    Ns_Entry *ent;
    if (!strncasecmp(domain,"www.",4))
    {
        rc=dom_init(oc,domain+4);
        return(rc);
    }
    
    ent=Ns_CacheCreateEntry(oc->globaldomaincache,domain,&new);
    if (new)
    {
        DqeVh_DomainQuery dq;
        dq.domain=domain;
        strncpy(dq.path,oc->pageroot,DQEVH_PATH_SIZE);
        dq.path[DQEVH_PATH_SIZE-1]=0;
        
        pl_call(oc->domainplist,&dq);
        
        rc=Ns_Malloc(sizeof(struct dqe_Vh_DomainEntry));
        rc->refcount=2;
        memcpy(rc->path,dq.path,DQEVH_PATH_SIZE);
        rc->path[DQEVH_PATH_SIZE-1]=0;
        Ns_CacheSetValueSz(ent,rc,sizeof(rc));
    }
    else
    {
        rc=Ns_CacheGetValue(ent);
        rc->refcount++;
    }
    return(rc);
}
/* }}} */
void dom_flush(struct dqe_Vh_DomainEntry *ent) /* {{{ */
{
    ent->refcount--;
    if (ent->refcount<=0)
    {
        Ns_Free(ent);
    }
}
/* }}} */

/* Tcl command */
static int dqe_VhCmd(struct dqe_Vh_OpCtx *oc, Tcl_Interp *interp, int objc, Tcl_Obj *CONST objv[]) /* {{{ */
{
    enum { C_TEST, C_URL2FILE, C_FLUSH, C_MAX };
    static char *subcmd[]= {
        "test",
        "url2file",
        "flush",
        NULL };
    int cmd;

    if (objc<2)
    {
        Tcl_WrongNumArgs(interp,1,objv,"command ?args?");
    }
    if (Tcl_GetIndexFromObj(interp,objv[1],subcmd,"command",0,&cmd)!=TCL_OK)
        return TCL_ERROR;

    switch (cmd)
    {
        case C_TEST:
        {
            return TCL_OK;
        }
        case C_URL2FILE:
        {
            Ns_DString ds;

            if (objc!=4)
            {
                Tcl_WrongNumArgs(interp,2,objv,"domain url");
                return TCL_ERROR;
            }
            Ns_DStringInit(&ds);
            DqeVh_Url2File(DqeVh_Ctx(Ns_TclInterpServer(interp)),&ds,Tcl_GetString(objv[2]),Tcl_GetString(objv[3]));
            Tcl_SetObjResult(interp,Tcl_NewStringObj(Ns_DStringValue(&ds),Ns_DStringLength(&ds)));
            Ns_DStringFree(&ds);
            return TCL_OK;
            break;
        }
        case C_FLUSH:
        {
            Ns_CacheLock(oc->globaldomaincache);
            Ns_CacheFlush(oc->globaldomaincache);
            Ns_CacheUnlock(oc->globaldomaincache);
            return TCL_OK;
            break;
        }
    }
    
    return TCL_ERROR;
}
/* }}} */

/* handlers */
static int _Filter(struct dqe_Vh_OpCtx *oc, Ns_Conn *conn, int why) /* {{{ */
{
    DqeVh_FilterQuery fq;
    struct dqe_Vh_Tls *tls;
    if (why!=NS_FILTER_POST_AUTH)
        return(NS_OK);
    tls=tls_initconn(oc,conn);
    fq.conn=conn;
    fq.method=conn->request->method;
    fq.domain=tls->hostname;
    fq.url=conn->request->url;
    fq.dobreak=0;
    fq.pageroot=tls->conndomain->path;
    
    snprintf(fq.domurl,sizeof(fq.domurl),"%s:%s",fq.domain,fq.url);
    pl_call(oc->filterplist,&fq);

    if (fq.dobreak)
        return NS_FILTER_RETURN;
    else
        return NS_OK;
}
/* }}} */
static int _UrlToFile(Ns_DString *dsPtr, char *server, char *url) /* {{{ */
{
    void *ctx;
    struct dqe_Vh_Tls *tls;
    if ((ctx=DqeVh_Ctx(server))!=NULL)
    {
        if ((tls=tls_initconn(ctx,Ns_TclGetConn(NULL))))
        {
            if (tls->initialized)
            {
                DqeVh_Url2FileDom(ctx,dsPtr,tls->hostname,tls->conndomain,url);
                return NS_OK;
            }
        }
    }
    return NS_ERROR;
}
/* }}} */
static char *_ConnLoc(Ns_Conn *conn) /* {{{ */
{
    return("A");
}
/* }}} */
static void _AtClose(struct dqe_Vh_OpCtx *oc) /* {{{ */
{
    struct dqe_Vh_Tls *tls;
    if ((tls=tls_get(oc,0))!=NULL)
    {
        Ns_CacheLock(oc->globaldomaincache);
        dom_flush(tls->conndomain);
        Ns_CacheUnlock(oc->globaldomaincache);
        tls->initialized=0;
    }
}
/* }}} */

/* initialization */
static int dqe_Vh_TclInit(Tcl_Interp *interp, struct dqe_Vh_OpCtx *oc) /* {{{ */
{
    Tcl_CreateObjCommand(interp,"dqe_vh",(Tcl_ObjCmdProc *) dqe_VhCmd,oc,NULL);
    return NS_OK;
}
/* }}} */
void dqe_Vh_Init(char *server, char *module) /* {{{ */
{
    struct dqe_Vh_OpCtx *oc;
    char *path;
    if (nsss_id<0)
    {
        nsss_id=Ns_ServerSpecificAlloc();
    }
    if ((oc=Ns_Malloc(sizeof(struct dqe_Vh_OpCtx)))!=NULL)
    {
        if ((path=Ns_ConfigGetPath(server,module,"vh",NULL))!=NULL)
        {
            if (Ns_ConfigGetInt(path,"domaincachesize",&oc->globaldomaincachesize)!=NS_TRUE)
                oc->globaldomaincachesize=262144;
        }
        else
        {
            oc->globaldomaincachesize=262144;
        }
        
        Ns_TclInitInterps(server,(Ns_TclInterpInitProc *) dqe_Vh_TclInit,oc);
        
        Ns_TlsAlloc(&oc->tlsdata,(Ns_Callback *) tls_free);
        
        Ns_ServerSpecificSet(server, nsss_id, oc, NS_OP_NODELETE, NULL);
        
        oc->globaldomaincache=Ns_CacheCreateSz("dqe_vh_domain",TCL_STRING_KEYS,oc->globaldomaincachesize,(Ns_Callback *) dom_flush);

        oc->pageroot=Ns_PageRoot(server);
        oc->servername=server;

        oc->domainplist=pl_create();
        oc->urlplist=pl_create();
        oc->filterplist=pl_create();
        
        // Ns_SetConnLocationProc((Ns_LocationProc *) _ConnLoc);
        Ns_SetUrlToFileProc(server, _UrlToFile);
        Ns_RegisterCleanup((Ns_TraceProc *) _AtClose,oc);
        Ns_RegisterFilter(server,"GET","*",(Ns_FilterProc *) _Filter,NS_FILTER_POST_AUTH,oc);

        Ns_Log(Notice,"%s::Vh loaded",server);
    }
}
/* }}} */

