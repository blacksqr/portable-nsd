#ifndef DQEPARSER_H
#define DQEPARSER_H 1

#include "dqe.h"

#define TCL_PROC_NAME       "dqe::parser::parse"

#endif
