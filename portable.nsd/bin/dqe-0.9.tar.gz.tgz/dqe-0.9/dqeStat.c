#include "dqe.h"
#include "dqeStat.h"

/* commands {{{ */
enum {
    DS_INIT,
    DS_QUERY,
    DS_OP,
    DS_GET,
    DS_CLEAR,
    DS_STATS,
    DS_STATCLR,
    DS_MAX
};
static char *ds_idx[] = {
    "init",
    "query",
    "op",
    "get",
    "clear",
    "stats",
    "statclr",
    NULL
};
/* }}} */
/* data/hash {{{ */
static Ns_Mutex ds_mutex;
static struct Tcl_HashTable ds_hash;
struct ds_StatData {
    int ds_q;
    int ds_o;
};
/* }}} */
/* data/hash commands {{{ */
inline static Tcl_HashEntry *dqe_findStat(char *name)
{
    Tcl_HashEntry *rc;
    int _new;
    if ((rc=Tcl_CreateHashEntry(&ds_hash,name,&_new))!=NULL)
    {
        if (_new)
        {
            struct ds_StatData *sd;
            sd=Ns_Malloc(sizeof(struct ds_StatData));
            sd->ds_q=0;
            sd->ds_o=0;
            Tcl_SetHashValue(rc,sd);
        }
    }
    return(rc);
}
/* }}} */
static int dqe_StatCmd(struct dqe_Stat_OpCtx *oc, Tcl_Interp *interp, int objc, Tcl_Obj *CONST objv[]) /* {{{ */
{
    int cmd;
    char *nam;
    Tcl_HashEntry *he;
    struct ds_StatData *sd;
    if (objc!=3)
    {
        Tcl_WrongNumArgs(interp,1,objv,"command name");
        return TCL_ERROR;
    }
    if (Tcl_GetIndexFromObj(interp,objv[1],ds_idx,"option",0,&cmd)!=TCL_OK)
        return TCL_ERROR;
    
    nam=Tcl_GetString(objv[2]);
    Ns_MutexLock(&ds_mutex);
    switch (cmd)
    {
        case DS_CLEAR:
        case DS_INIT:
            he=dqe_findStat(nam);
            if ((sd=Tcl_GetHashValue(he))!=NULL)
            {
                sd->ds_q=0;
                sd->ds_o=0;
            }
            break;
        case DS_QUERY:
            he=dqe_findStat(nam);
            if ((sd=Tcl_GetHashValue(he))!=NULL)
                sd->ds_q++;
            break;
        case DS_OP:
            he=dqe_findStat(nam);
            if ((sd=Tcl_GetHashValue(he))!=NULL)
                sd->ds_o++;
            break;
        case DS_GET:
            he=dqe_findStat(nam);
            if ((sd=Tcl_GetHashValue(he))!=NULL)
            {
                Tcl_Obj *o;
                if ((o=Tcl_NewListObj(0,NULL))!=NULL)
                {
                    Tcl_ListObjAppendElement(interp,o,Tcl_NewIntObj(sd->ds_o));
                    Tcl_ListObjAppendElement(interp,o,Tcl_NewIntObj(sd->ds_q));
                    Tcl_SetObjResult(interp,o);
                }
            }
            break;
        case DS_STATS:
            {
                Tcl_Obj *o,*oe;
                Tcl_HashSearch se;
                
                if ((o=Tcl_NewListObj(0,NULL))!=NULL)
                {
                    for (he=Tcl_FirstHashEntry(&ds_hash,&se);he;he=Tcl_NextHashEntry(&se))
                    {
                        if (Tcl_StringMatch(Tcl_GetHashKey(&ds_hash,he),nam))
                        {
                            if ((sd=Tcl_GetHashValue(he))!=NULL)
                            {
                                if ((oe=Tcl_NewListObj(0,NULL))!=NULL)
                                {
                                    Tcl_ListObjAppendElement(interp,oe,Tcl_NewStringObj(Tcl_GetHashKey(&ds_hash,he),-1));
                                    Tcl_ListObjAppendElement(interp,oe,Tcl_NewIntObj((sd->ds_q)-(sd->ds_o)));
                                    Tcl_ListObjAppendElement(interp,oe,Tcl_NewIntObj(sd->ds_q));
                                }
                                Tcl_ListObjAppendElement(interp,o,oe);
                            }
                        }
                    }
                    Tcl_SetObjResult(interp,o);
                }
            }
            break;
        case DS_STATCLR:
            {
                Tcl_Obj *o,*oe;
                Tcl_HashSearch se;
                
                if ((o=Tcl_NewListObj(0,NULL))!=NULL)
                {
                    for (he=Tcl_FirstHashEntry(&ds_hash,&se);he;he=Tcl_NextHashEntry(&se))
                    {
                        if (Tcl_StringMatch(Tcl_GetHashKey(&ds_hash,he),nam))
                        {
                            if ((sd=Tcl_GetHashValue(he))!=NULL)
                            {
                                if ((oe=Tcl_NewListObj(0,NULL))!=NULL)
                                {
                                    Tcl_ListObjAppendElement(interp,oe,Tcl_NewStringObj(Tcl_GetHashKey(&ds_hash,he),-1));
                                    Tcl_ListObjAppendElement(interp,oe,Tcl_NewIntObj((sd->ds_q)-(sd->ds_o)));
                                    Tcl_ListObjAppendElement(interp,oe,Tcl_NewIntObj(sd->ds_q));
                                    sd->ds_o=0;
                                    sd->ds_q=0;
                                }
                                Tcl_ListObjAppendElement(interp,o,oe);
                            }
                        }
                    }
                    Tcl_SetObjResult(interp,o);
                }
            }
            break;
    }
    Ns_MutexUnlock(&ds_mutex);
    return TCL_OK;
}
/* }}} */
static int dqe_Stat_TclInit(Tcl_Interp *interp, struct dqe_Stat_OpCtx *oc) /* {{{ */
{
    Tcl_CreateObjCommand(interp,"dqe_stat",(Tcl_ObjCmdProc *) dqe_StatCmd,oc,NULL);
    return NS_OK;
}
/* }}} */
void dqe_Stat_Init(char *server, char *module) /* {{{ */
{
    struct dqe_Stat_OpCtx *oc;
    if ((oc=Ns_Malloc(sizeof(struct dqe_Stat_OpCtx)))!=NULL)
    {
        Ns_MutexInit(&ds_mutex);
        Tcl_InitHashTable(&ds_hash,TCL_STRING_KEYS);
        Ns_TclInitInterps(server,(Ns_TclInterpInitProc *) dqe_Stat_TclInit,oc);
        Ns_Log(Notice,"%s::Stat loaded",server);
    }
}
/* }}} */

