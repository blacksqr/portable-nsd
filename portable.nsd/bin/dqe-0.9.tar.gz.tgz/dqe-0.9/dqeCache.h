#ifndef DQECACHE_H
#define DQECACHE_H 1

#include "dqe.h"

struct dqe_Cache_OpCtx {
    int tlscachesize;
    Tcl_HashTable cachelist;
    Ns_ThreadLocalStorage cachetls;
};

struct dqe_Cache_TclObjEntry {
    Ns_Time stamp;
    Tcl_Obj *obj;
};

struct dqe_Cache_DcEntry {
    Ns_Time stamp;
    int refcount;
    void *ptr;
};

struct dqe_Cache_CacheEntry {
    Ns_Cache *cache;
    int timeout;
    int size;
};

#endif
