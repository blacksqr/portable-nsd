#include "dqe.h"
#include "dqeUtils.h"

static int LcompareCmd(struct dqe_Utils_OpCtx *oc, Tcl_Interp *interp, int objc, Tcl_Obj *CONST objv[]) /* {{{ */
{
    Tcl_Obj *rclist=NULL,*rcl[]={NULL,NULL},*sl,*dl,*sel,*del;
    int sli,sll,dli,dll,scmp;
    
    if (objc!=3)
    {
        Tcl_WrongNumArgs(interp,1,objv,"srclist dstlist");
        return TCL_ERROR;
    }

    if ((rcl[0]=Tcl_NewListObj(0,NULL))==NULL)
        return TCL_ERROR;
    if ((rcl[1]=Tcl_NewListObj(0,NULL))==NULL)
    {
        Tcl_IncrRefCount(rcl[0]);
        Tcl_DecrRefCount(rcl[0]);
        return TCL_ERROR;
    }
    if ((rclist=Tcl_NewListObj(2,rcl))==NULL)
    {
        Tcl_IncrRefCount(rcl[0]);
        Tcl_DecrRefCount(rcl[0]);
        Tcl_IncrRefCount(rcl[1]);
        Tcl_DecrRefCount(rcl[1]);
        return TCL_ERROR;
    }
    
    sl=objv[1];
    dl=objv[2];
    
    if (Tcl_ListObjLength(interp,sl,&sll)!=TCL_OK)
        goto onerror;
    if (Tcl_ListObjLength(interp,dl,&dll)!=TCL_OK)
        goto onerror;
    
    sli=0;dli=0;

    // main loop
    while ((sli<sll)&&(dli<dll))
    {
        if (Tcl_ListObjIndex(interp,sl,sli,&sel)!=TCL_OK)
            goto onerror;
        if (Tcl_ListObjIndex(interp,dl,dli,&del)!=TCL_OK)
            goto onerror;
        
        scmp=strcmp(Tcl_GetString(sel),Tcl_GetString(del));
        if (scmp<0)
        {
            sli++;
            if (Tcl_ListObjAppendElement(interp,rcl[1],sel)!=TCL_OK)
                goto onerror;
        }
        else if (scmp>0)
        {
            dli++;
            if (Tcl_ListObjAppendElement(interp,rcl[0],del)!=TCL_OK)
                goto onerror;
        }
        else if (scmp==0)
        {
            sli++;
            dli++;
        }
        // break;
    }

    while (sli<sll)
    {
        if (Tcl_ListObjIndex(interp,sl,sli,&sel)!=TCL_OK)
            goto onerror;
        if (Tcl_ListObjAppendElement(interp,rcl[1],sel)!=TCL_OK)
            goto onerror;
        sli++;
    }
    while (dli<dll)
    {
        if (Tcl_ListObjIndex(interp,dl,dli,&del)!=TCL_OK)
            goto onerror;
        if (Tcl_ListObjAppendElement(interp,rcl[0],del)!=TCL_OK)
            goto onerror;
        dli++;
    }
    
    Tcl_SetObjResult(interp,rclist);
    return TCL_OK;
onerror:
    if (rclist)
    {
        Tcl_ListObjReplace(interp,rclist,0,2,0,NULL);
        Tcl_IncrRefCount(rclist);
        Tcl_DecrRefCount(rclist);
    }
    return TCL_ERROR;
}
/* }}} */
static int ReturnDataCmd(struct dqe_Utils_OpCtx *oc, Tcl_Interp *interp, int objc, Tcl_Obj *CONST objv[]) /* {{{ */
{
    char *d,*t;
    int siz;
    int c;
    int rc;
    int mtime;
    time_t t_mtime;
    Ns_Conn *conn;

    if ((objc<4)||(objc>5))
    {
        Tcl_WrongNumArgs(interp,1,objv,"code type data ?mtime?");
        return TCL_ERROR;
    }
    if ((rc=Tcl_GetIntFromObj(interp,objv[1],&c))!=TCL_OK)
        return(rc);

    conn=Ns_TclGetConn(NULL);
    if (conn==NULL)
        return TCL_ERROR;


    if ((objc>4)&&(c==200))
    {
        if ((rc=Tcl_GetIntFromObj(interp,objv[4],&mtime))!=TCL_OK)
            return(rc);
        t_mtime=mtime;
        if (!Ns_ConnModifiedSince(conn,t_mtime))
        {
            Ns_ReturnNotModified(conn);
            Tcl_SetObjResult(interp,Tcl_NewBooleanObj(1));
            return TCL_OK;
        }
        Ns_ConnSetLastModifiedHeader(conn,&t_mtime);
    }
    t=Tcl_GetString(objv[2]);
    d=Tcl_GetStringFromObj(objv[3],&siz);
    Ns_ConnReturnData(conn,c,d,siz,t);
    Tcl_SetObjResult(interp,Tcl_NewBooleanObj(0));
    return TCL_OK;
} /* }}} */
static int MiscCmd(struct dqe_Utils_OpCtx *oc, Tcl_Interp *interp, int objc, Tcl_Obj *CONST objv[]) /* {{{ */
{
    enum { S_OBJTYPE, S_MAX };
    static char *ds_sub[] = { "objtype", NULL };
    char *d,*t;
    int siz;
    int c;
    int rc;
    int cmd;

    if (objc<2)
    {
        Tcl_WrongNumArgs(interp,1,objv,"subcommand ?arg1 ...?");
        return TCL_ERROR;
    }
    if (Tcl_GetIndexFromObj(interp,objv[1],ds_sub,"subcommand",0,&cmd)!=TCL_OK)
        return TCL_ERROR;
    
    switch (cmd)
    {
        case S_OBJTYPE:
            {
                if (objc!=3)
                {
                    Tcl_WrongNumArgs(interp,2,objv,"value");
                    return TCL_ERROR;
                }

                if (objv[2]->typePtr!=NULL)
                {
                    Tcl_SetObjResult(interp,Tcl_NewStringObj(objv[2]->typePtr->name,-1));
                }
                else
                {
                    Tcl_SetObjResult(interp,Tcl_NewStringObj("",0));
                }
            }
            break;
    }

    return TCL_OK;
} /* }}} */
static int ThNamCmd(struct dqe_Utils_OpCtx *oc, Tcl_Interp *interp, int objc, Tcl_Obj *CONST objv[]) /* {{{ */
{
    if ((objc<1)||(objc>2))
    {
        Tcl_WrongNumArgs(interp,1,objv,"?threadname?");
        return TCL_ERROR;
    }  
    else if (objc==2)  
    {
        Ns_ThreadSetName(Tcl_GetString(objv[1]));
    }
    else if (objc==1)
    {
        Tcl_SetObjResult(interp,Tcl_NewStringObj(Ns_ThreadGetName(),-1));
    }
    return TCL_OK;
} /* }}} */
static int dqe_Utils_TclInit(Tcl_Interp *interp, ClientData oc) /* {{{ */
{
    Tcl_CreateObjCommand(interp,"dqe_threadname",(Tcl_ObjCmdProc *) ThNamCmd,(ClientData) oc,NULL);
    Tcl_CreateObjCommand(interp,"dqe_return",(Tcl_ObjCmdProc *) ReturnDataCmd,(ClientData) oc,NULL);
    Tcl_CreateObjCommand(interp,"dqe_lcompare",(Tcl_ObjCmdProc *) LcompareCmd,(ClientData) oc,NULL);
    Tcl_CreateObjCommand(interp,"dqe_misc",(Tcl_ObjCmdProc *) MiscCmd,(ClientData) oc,NULL);
    return TCL_OK;
}
/* }}} */
void dqe_Utils_Init(char *server, char *module) /* {{{ */
{
    Ns_TclInitInterps(server,(Ns_TclInterpInitProc *) dqe_Utils_TclInit,NULL);
    Ns_Log(Notice,"%s::Utilities loaded",server);
}
/* }}} */

