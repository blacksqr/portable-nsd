#include "dqe.h"
#include "dqeEnc.h"

#define ENC_USE_TOKENS 1

enum {
    EC_DEFAULT,
    EC_ENCODING,
    EC_NOCONV,
    EC_AMPHASH,
    EC_BINARY,
    EC_MAX
};
/* 
 * 0/ "" (default encoding)
 * 1/ encoding
 * 2/ "-" (no conversion)
 */

struct enc_done_token {
    struct enc_done_token *next;
    Tcl_Obj *from;
    Tcl_Obj *to;
};

struct enc_private_data { /* {{{ */
    Tcl_ObjType *ot_string;
    Tcl_ObjType *ot_int;
    Tcl_ObjType *ot_long;
    Tcl_ObjType *ot_double;
    Tcl_ObjType *ot_list;
    struct enc_done_token *token;
    struct enc_done_token token0;
};
/* }}} */
void pd_init(struct enc_private_data *rc) /* {{{ */
{
    memset(rc,0,sizeof(struct enc_private_data));
#ifdef ENC_USE_TOKENS 
    rc->token=&rc->token0;
#endif
}
/* }}} */
void pd_free(struct enc_private_data *pd) /* {{{ */
{
#ifdef ENC_USE_TOKENS 
    struct enc_done_token *t,*tn;
#endif
#ifdef ENC_USE_TOKENS 
    t=pd->token;
    while ((tn=t->next)!=NULL)
    {
        Ns_Free(t);
        t=tn;
    }
#endif
}
/* }}} */
/* enc_convObj() {{{ */
static Tcl_Obj *enc_convObj(struct dqe_Enc_OpCtx *oc, Tcl_Interp *interp, 
        Tcl_Obj *oobj, 
        int sconv, int dconv, 
        Tcl_Encoding se, Tcl_Encoding de,
        Tcl_DString *ds1, Tcl_DString *ds2,
        struct enc_private_data *pd
        )
{
    struct enc_done_token *token;
    enum { T_UNKNOWN, T_STRING, T_INT, T_LONG, T_DOUBLE, T_LIST };
    int slen;
    int otype=T_UNKNOWN;
    char *sstr;
    Tcl_Obj *obj=oobj;
    Tcl_ObjType *ot;

    ot=obj->typePtr;

#ifdef ENC_USE_TOKENS 
    for (token=pd->token;token->next;token=token->next)
    {
        if (token->from==obj)
        {
            return(token->to);
        }
    }
#endif
    if (ot==NULL)
    {
        otype=T_STRING;
    }
    else if (ot==pd->ot_string)
        otype=T_STRING;
    else if (ot==pd->ot_int)
        otype=T_INT;
    else if (ot==pd->ot_long)
        otype=T_LONG;
    else if (ot==pd->ot_double)
        otype=T_DOUBLE;
    else if (ot==pd->ot_list)
        otype=T_LIST;

    if (otype==T_UNKNOWN)
    {
        if (!strcmp(ot->name,"string"))
        {
            otype=T_STRING;
            pd->ot_string=ot;
        }
        if (!strcmp(ot->name,"int"))
        {
            otype=T_INT;
            pd->ot_int=ot;
        }
        if (!strcmp(ot->name,"long"))
        {
            otype=T_LONG;
            pd->ot_long=ot;
        }
        if (!strcmp(ot->name,"double"))
        {
            otype=T_DOUBLE;
            pd->ot_double=ot;
        }
        if (!strcmp(ot->name,"list"))
        {
            otype=T_LIST;
            pd->ot_list=ot;
        }
    }

    if ((otype==T_INT)||(otype==T_LONG))
    {
        /* no conversion required */
        obj=obj;
    }
    else
    if ((otype==T_LIST))
    {
        /* convert every element */
        int llen,i;
        Tcl_Obj *eobj,*nobj;
        Tcl_Obj **newlist;

        if (Tcl_ListObjLength(NULL,obj,&llen)==TCL_OK)
        {
            newlist=Ns_Malloc(sizeof(Tcl_Obj *)*llen);
            for (i=0;i<llen;i++)
            {
                if (Tcl_ListObjIndex(NULL,obj,i,&eobj)==TCL_OK)
                {
                    nobj=enc_convObj(oc,interp,eobj,sconv,dconv,se,de,ds1,ds2,pd);
                    newlist[i]=nobj;
                }
            }
            obj=Tcl_NewListObj(llen,newlist);
            Ns_Free(newlist);
        }
    }
    else
    {
        /* convert as a string */
        Tcl_DStringSetLength(ds1,0);
        Tcl_DStringSetLength(ds2,0);
        
        sstr=Tcl_GetStringFromObj(obj,&slen);
        switch (sconv)
        {
            case EC_DEFAULT:
            case EC_ENCODING:
                Tcl_ExternalToUtfDString(se,sstr,slen,ds1);
                break;
            case EC_AMPHASH:
                /* &#32; -> ' ' not implemented yet */
            case EC_NOCONV:
                Tcl_DStringAppend(ds1,sstr,slen);
                break;
        }
        
        /* ds1 -> ds2 */
        switch (dconv)
        {
            case EC_DEFAULT:
            case EC_ENCODING:
                Tcl_UtfToExternalDString(de,Tcl_DStringValue(ds1),Tcl_DStringLength(ds1),ds2);
                break;
            case EC_NOCONV:
                Tcl_DStringAppend(ds2,Tcl_DStringValue(ds1),Tcl_DStringLength(ds1));
                break;
            case EC_AMPHASH:
                {
                    int len,i,n;
                    char *ds,buf[32];
                    Tcl_UniChar uc;
                    len=Tcl_NumUtfChars(Tcl_DStringValue(ds1),Tcl_DStringLength(ds1));
                    for (i=0,ds=Tcl_DStringValue(ds1);i<len;i++)
                    {
                        Tcl_UtfToUniChar(ds,&uc);
                        if (uc>127)
                        {
                            n=sprintf(buf,"&#%d;",uc);
                            Tcl_DStringAppend(ds2,buf,n);
                        }  else  {
                            Tcl_UniCharToUtfDString(&uc,1,ds2);
                        }
                        ds=Tcl_UtfNext(ds);
                    }
                }
                break;
        }
        obj=Tcl_NewStringObj(Tcl_DStringValue(ds2),Tcl_DStringLength(ds2));
    }
#ifdef ENC_USE_TOKENS 
    if ((token=Ns_Malloc(sizeof (struct enc_done_token)))!=NULL)
    {
        token->from=oobj;
        token->to=obj;
        token->next=pd->token;
        pd->token=token;
    }
#endif
    return(obj);
}
/* }}} */
static int EncCmd(struct dqe_Enc_OpCtx *oc, Tcl_Interp *interp, int objc, Tcl_Obj *CONST objv[]) /* {{{ */
{
    Tcl_Encoding se=NULL, de=NULL;
    Tcl_DString ds1,ds2;
    int rc=TCL_ERROR,ok=1,sconv,dconv,slen;
    char *sen,*den,*sstr;
    Tcl_Obj *obj;
    struct enc_private_data pd;
    
    if (objc!=4)
    {
        Tcl_WrongNumArgs(interp,1,objv,"from to string");
        return TCL_ERROR;
    }
    
    /* encodings {{{ */
    sen=Tcl_GetString(objv[1]);
    den=Tcl_GetString(objv[2]);
    if ((*sen!='\0')&&(*sen!='-')&&(*sen!='&'))
    {
        if (!(se=Tcl_GetEncoding(interp,sen)))
            ok=0;
        sconv=EC_ENCODING;
    }
    else
    {
        if (*sen=='-')
            sconv=EC_NOCONV;
        else if (*sen=='&')
            sconv=EC_AMPHASH;
        else
            sconv=EC_DEFAULT;
    }
    if ((*den!='\0')&&(*den!='-')&&(*den!='&'))
    {
        if (!(de=Tcl_GetEncoding(interp,den)))
            ok=0;
        dconv=EC_ENCODING;
    }
    else
    {
        if (*den=='-')
            dconv=EC_NOCONV;
        else if (*den=='&')
            dconv=EC_AMPHASH;
        else
            dconv=EC_DEFAULT;
    }
    /* }}} */
    
    Tcl_DStringInit(&ds1);
    Tcl_DStringInit(&ds2);

    if (ok)
    {
        pd_init(&pd);
        obj=enc_convObj(oc,interp, objv[3], sconv, dconv, se, de, &ds1, &ds2,&pd);
        Tcl_SetObjResult(interp,obj);
        pd_free(&pd);
        rc=TCL_OK;
    }
    
    Tcl_DStringFree(&ds1);
    Tcl_DStringFree(&ds2);

    if (de)
        Tcl_FreeEncoding(de);
    if (se)
        Tcl_FreeEncoding(se);
    return(rc);
}
/* }}} */
static int dqe_Enc_TclInit(Tcl_Interp *interp, struct dqe_Enc_OpCtx *oc) /* {{{ */
{
    Tcl_CreateObjCommand(interp,"dqe_enc",(Tcl_ObjCmdProc *) EncCmd,(ClientData) oc,NULL);
    return TCL_OK;
}
/* }}} */
void dqe_Enc_Init(char *server, char *module) /* {{{ */
{
    struct dqe_Enc_OpCtx *oc;
    char *path,*cval;
    if ((oc=Ns_Malloc(sizeof(struct dqe_Enc_OpCtx)))!=NULL)
    {
        oc->e_Encoding=NULL;
        if ((path=Ns_ConfigGetPath(server,module,"encoding",NULL))!=NULL)
        {
            cval=Ns_ConfigGetValue(path,"encoding");
            if (cval)
                oc->e_Encoding=cval;
        }
        Ns_TclInitInterps(server,(Ns_TclInterpInitProc *) dqe_Enc_TclInit,oc);
        Ns_Log(Notice,"%s::Encoding loaded",server);
    }
}
/* }}} */

