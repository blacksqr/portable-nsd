#include "dqe.h"
#include "dqeCache.h"
#include "deepcopy.h"

/* commands {{{ */
enum {
    C_CREATE,
    C_EVAL,
    C_FLUSH,
    C_MAX
};
static char *c_idx[] = {
    "create",
    "eval",
    "flush",
    NULL
};
/* }}} */

static void c_flush_dc(void *ptr) /* {{{ */
{
    struct dqe_Cache_DcEntry *e=ptr;
    if (e)
    {
        if (e->ptr)
        {
            Dc_FreeDcObj(e->ptr);
        }
        Ns_Free(e);
    }
}
/* }}} */

static void threadlocalcache_delete(Ns_Cache *c) /* {{{ */
{
    if (c)
    {
        Ns_Log(Debug,"TODO: flush local cache entries");
    }
}
/* }}} */
static void tlscacheflush(struct dqe_Cache_TclObjEntry *ptr) /* {{{ */
{
    if (ptr)
    {
        Tcl_DecrRefCount(ptr->obj);
        Ns_Free(ptr);
    }
}
/* }}} */
static Ns_Cache *threadlocalcache(struct dqe_Cache_OpCtx *oc) /* {{{ */
{
    Ns_Cache *cache;
    char buf[64];
    sprintf(buf,"dqetls%d",Ns_ThreadId());

    // reuse already created temporary cache structures
    Ns_GetThreadLocalStorage(&oc->cachetls,&cache);
    if (cache==NULL)
    {
        if ((cache=Ns_CacheFind(buf))==NULL)
        {
            cache=Ns_CacheCreateSz(buf,TCL_STRING_KEYS,oc->tlscachesize,(Ns_Callback *) tlscacheflush);
        }
        Ns_SetThreadLocalStorage(&oc->cachetls,cache);
    }
    return(cache);
}
/* }}} */
static Tcl_Obj *c_renderdc(struct dqe_Cache_OpCtx *oc, struct dqe_Cache_DcEntry *dce, Ns_Cache *cache, char *key) /* {{{ */
{
    Ns_Cache *localcache;
    Ns_Entry *lcentry;
    Tcl_Obj *obj;
    char buf[1024];
    int new;
    struct dqe_Cache_TclObjEntry *cobj;
    
    snprintf(buf,1020,"%p%s",cache,key);
    
    localcache=threadlocalcache(oc);
    lcentry=Ns_CacheCreateEntry(localcache,buf,&new);
    cobj=Ns_CacheGetValue(lcentry);
    if (!new)
    {
        cobj=Ns_CacheGetValue(lcentry);
        if (memcmp(&cobj->stamp,&dce->stamp,sizeof(Ns_Time))!=0)
        {
            new=1;
            Ns_CacheUnsetValue(lcentry);
        }
    }
    if (new)
    {
        cobj=Ns_Malloc(sizeof(struct dqe_Cache_TclObjEntry));
        cobj->obj=Dc_NewTclObj(dce->ptr);
        memcpy(&cobj->stamp,&dce->stamp,sizeof(Ns_Time));
        Tcl_IncrRefCount(cobj->obj);
        Ns_CacheSetValueSz(lcentry,cobj,Dc_ObjSize(dce->ptr));
    }
    else
    {
        cobj=Ns_CacheGetValue(lcentry);
    }
    return(cobj->obj);
}
/* }}} */
static Ns_Cache *c_create(struct dqe_Cache_OpCtx *oc, char *name,int timeout, int size) /* {{{ */
{
    Ns_Cache *rc=NULL;
    Tcl_HashEntry *he;
    struct dqe_Cache_CacheEntry *cacheentry;
    int new;

    he=Tcl_CreateHashEntry(&oc->cachelist,name,&new);
    if (new)
    {
        if (timeout<0)
            rc=Ns_CacheCreateSz(name,TCL_STRING_KEYS,size,c_flush_dc);
        else
            rc=Ns_CacheCreate(name,TCL_STRING_KEYS,timeout,c_flush_dc);
        
        if ((cacheentry=Ns_Malloc(sizeof(struct dqe_Cache_CacheEntry)))!=NULL)
        {
            cacheentry->cache=rc;
            cacheentry->timeout=timeout;
            cacheentry->size=size;
            Tcl_SetHashValue(he,cacheentry);
        }
    }
    return(rc);
}
/* }}} */
static Ns_Cache *c_find(struct dqe_Cache_OpCtx *oc, char *name) /* {{{ */
{
    return(Ns_CacheFind(name));
}
/* }}} */

static int dqe_CacheCmd(struct dqe_Cache_OpCtx *oc, Tcl_Interp *interp, int objc, Tcl_Obj *CONST objv[]) /* {{{ */
{
    int cmd,val;
    char *nam;
    Tcl_HashEntry *he;
    struct ds_StatData *sd;
    if (objc<3)
    {
        Tcl_WrongNumArgs(interp,1,objv,"command cachename ?args?");
        return TCL_ERROR;
    }
    if (Tcl_GetIndexFromObj(interp,objv[1],c_idx,"option",0,&cmd)!=TCL_OK)
        return TCL_ERROR;
    
    nam=Tcl_GetString(objv[2]);
    switch (cmd)
    {
        case C_CREATE: /* {{{ */
        {
            int v0,v1;
            if (objc!=4)
            {
                Tcl_WrongNumArgs(interp,3,objv,"limit");
                return TCL_ERROR;
            }
            if (Tcl_GetIntFromObj(interp,objv[3],&val)!=TCL_OK)
                return TCL_ERROR;
            if (c_create(oc,nam,-1,val)==NULL)
            {
                Tcl_SetResult(interp,"Unable to create cache",NULL);
                return(TCL_ERROR);
            }
            break;
        }
        /* }}} */
        case C_EVAL: /* {{{ */
        {
            Ns_Cache *c;
            Ns_Entry *ce;
            void *dcobj;
            Tcl_Obj *res;
            
            char *key;
            int new;
            
            if (objc!=5)
            {
                Tcl_WrongNumArgs(interp,3,objv,"key command");
                return TCL_ERROR;
            }
            if (!(c=c_find(oc,nam)))
            {
                Tcl_SetResult(interp,"Unable to find cache",NULL);
                return TCL_ERROR;
            }
            key=Tcl_GetString(objv[3]);
            Ns_CacheLock(c);
            ce=Ns_CacheCreateEntry(c,key,&new);
            if (!new)
            {
                struct dqe_Cache_DcEntry *dce;
                dce=Ns_CacheGetValue(ce);
                Tcl_SetObjResult(interp,c_renderdc(oc,dce,c,key));
            }
            else
            {
                if (Tcl_EvalObjEx(interp,objv[4],TCL_EVAL_DIRECT)==TCL_OK)
                {
                    if ((res=Tcl_GetObjResult(interp))!=NULL)
                    {
                        struct dqe_Cache_DcEntry *dce;
                        if ((dce=Ns_Malloc(sizeof(struct dqe_Cache_DcEntry)))!=NULL)
                        {
                            dcobj=Dc_GetTclObj(res);
                            dce->ptr=dcobj;
                            Ns_GetTime(&dce->stamp);
                            Ns_CacheSetValueSz(ce,dce,Dc_ObjSize(dcobj));
                            Tcl_SetObjResult(interp,c_renderdc(oc,dce,c,key));
                        }
                    }
                    else
                    {
                        Ns_CacheDeleteEntry(ce);
                        Ns_CacheUnlock(c);
                    }
                }
                else
                {
                    Ns_CacheDeleteEntry(ce);
                    Ns_CacheUnlock(c);
                    return TCL_ERROR;
                }
            }
            Ns_CacheUnlock(c);
            break;
        }
        /* }}} */
        case C_FLUSH: /* {{{ */
        {
            Ns_Cache *c;
            Ns_Entry *ce;
            Ns_CacheSearch cs;
            
            char *key;
            int klen;
            
            if (objc!=4)
            {
                Tcl_WrongNumArgs(interp,3,objv,"keys");
                return TCL_ERROR;
            }
            if (!(c=c_find(oc,nam)))
            {
                Tcl_SetResult(interp,"Unable to find cache",NULL);
                return TCL_ERROR;
            }

            key=Tcl_GetStringFromObj(objv[3],&klen); 
            Ns_CacheLock(c);
            if (*key=='^')
            {
                key++;klen--;
                for (ce=Ns_CacheFirstEntry(c,&cs);ce;ce=Ns_CacheNextEntry(&cs))
                {
                    if (!memcmp(Ns_CacheKey(ce),key,klen))
                    {
                        Ns_CacheFlushEntry(ce);
                    }
                }
            }
            else
            {
                for (ce=Ns_CacheFirstEntry(c,&cs);ce;ce=Ns_CacheNextEntry(&cs))
                {
                    if (!strcmp(Ns_CacheKey(ce),key))
                    {
                        Ns_CacheFlushEntry(ce);
                    }
                }
            }
            Ns_CacheUnlock(c);

            break;
        }
        /* }}} */
    }
    return TCL_OK;
}
/* }}} */

static int dqe_Cache_TclInit(Tcl_Interp *interp, struct dqe_Cache_OpCtx *oc) /* {{{ */
{
    Tcl_CreateObjCommand(interp,"dqe_cache",(Tcl_ObjCmdProc *) dqe_CacheCmd,oc,NULL);
    return NS_OK;
}
/* }}} */
void dqe_Cache_Init(char *server, char *module) /* {{{ */
{
    struct dqe_Cache_OpCtx *oc;
    if ((oc=Ns_Malloc(sizeof(struct dqe_Cache_OpCtx)))!=NULL)
    {
        oc->tlscachesize=131072;
        Tcl_InitHashTable(&oc->cachelist,TCL_STRING_KEYS);
        Ns_TclInitInterps(server,(Ns_TclInterpInitProc *) dqe_Cache_TclInit,oc);
        Ns_Log(Notice,"%s::Cache loaded",server);
    }
}
/* }}} */

