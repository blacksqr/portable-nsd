#ifndef DQETHNAM_H
#define DQETHNAM_H 1

#include "dqe.h"

struct dqe_Utils_OpCtx {
    int dummy;
};

#endif
