#include "dqe.h"
#include "dqeAsync.h"

/* commands {{{ */
enum {
    C_CREATE,
    C_DELETE,
    C_COMMAND,
    C_ADD,
    C_MAX
};
static char *da_idx[] = {
    "create",
    "delete",
    "command",
    "add",
    NULL
};
/* }}} */
/* static data {{{ */
static Ns_Mutex da_lock;
static struct Tcl_HashTable hash;
/* }}} */
/* asyncdata {{{ */
static dqe_AsyncData *adCreate()
{
    dqe_AsyncData *rc;
    rc=Ns_Malloc(sizeof(dqe_AsyncData));
    if (rc!=NULL)
    {
        rc->da_Cmd=NULL;
        rc->da_Data=NULL;
        Ns_MutexInit(&rc->da_Mutex);
    }
    return(rc);
}
void adDelete(dqe_AsyncData *ad)
{
    if (ad)
    {
        Ns_MutexDestroy(&ad->da_Mutex);
        if (ad->da_Data)
            Ns_Free(ad->da_Data);
        if (ad->da_Cmd)
            Ns_Free(ad->da_Cmd);
        if (ad->da_AsyncHandler)
            Tcl_AsyncDelete(ad->da_AsyncHandler);
        Ns_Free(ad);
    }
}
void adSetCmd(dqe_AsyncData *ad,char *v)
{
    if (ad->da_Cmd)
        Ns_Free(ad->da_Cmd);
    if (v)
        ad->da_Cmd=Ns_StrDup(v);
    else
        ad->da_Cmd=NULL;
}
int adAddData(dqe_AsyncData *ad,char *v)
{
    dqe_AsyncDataCmd *c;
    if ((c=Ns_Malloc(sizeof(dqe_AsyncDataCmd)+strlen(v)))!=NULL)
    {
        strcpy(c->dac_Data,v);
        c->dac_Prev=ad->da_Data;
        ad->da_Data=c;
        return 1;
    }
    return 0;
}
/* }}} */
/* adEval {{{ */
static void adEvalCmd(dqe_AsyncData *ad, dqe_AsyncDataCmd *c, Tcl_Interp *interp, Tcl_Obj *cmdobj)
{
    Tcl_Obj *dobj,*o[2],*ccobj;
    if (!c)
        return;
    adEvalCmd(ad,c->dac_Prev,interp,cmdobj);
    
    if ((dobj=Tcl_NewStringObj(c->dac_Data,-1))!=NULL)
    {
        Tcl_IncrRefCount(dobj);
        o[0]=cmdobj;o[1]=dobj;
        ccobj=Tcl_ConcatObj(2,o);
        Tcl_IncrRefCount(ccobj);
        if (Tcl_EvalObjEx(interp,ccobj,0)==TCL_ERROR)
        {
            Ns_Log(Error,"%s",Tcl_GetVar(interp,"::errorInfo",0));
        }
        Tcl_DecrRefCount(ccobj);
        Tcl_DecrRefCount(dobj);
    }
    c->dac_Prev=NULL;
    Ns_Free(c);
}
static int adEval(ClientData clientdata, Tcl_Interp *interp)
{
    Tcl_Obj *obj;
    dqe_AsyncData *ad=(dqe_AsyncData *) clientdata;
    dqe_AsyncDataCmd *adc;
    
    Ns_MutexLock(&da_lock);
    adc=ad->da_Data;
    ad->da_Data=NULL;
    interp=ad->da_Interp;
    if ((obj=Tcl_NewStringObj(ad->da_Cmd,-1))!=NULL)
    {
        Tcl_IncrRefCount(obj);
        Ns_MutexUnlock(&da_lock);
        adEvalCmd(ad,adc,interp,obj);
        Tcl_DecrRefCount(obj);
    }
    else
    {
        Ns_MutexUnlock(&da_lock);
    }
    return TCL_OK;
}
/* }}} */
/* automatic names {{{ */
#define AUTONAMELEN     32

static int autoid=0;
char *asyncautoname(char buf[AUTONAMELEN])
{
    int id;
    id=++autoid;
    sprintf(buf,"async%d",id);
    return(buf);
}
/* }}} */
static int AsyncCmd(struct dqe_Async_OpCtx *oc, Tcl_Interp *interp, int objc, Tcl_Obj *CONST objv[]) /* {{{ */
{
    int cmd;
    Tcl_HashEntry *he;
    if (objc<2)
    {
        Tcl_WrongNumArgs(interp,1,objv,"command ?args?");
        return TCL_ERROR;
    }
    if (Tcl_GetIndexFromObj(interp,objv[1],da_idx,"command",0,&cmd)!=TCL_OK)
        return TCL_ERROR;
    
    switch (cmd)
    {
        case C_CREATE:
            {
                int new;
                char buf[AUTONAMELEN],*mname;

                if (objc>4)
                {
                    Tcl_WrongNumArgs(interp,2,objv,"?name?");
                    return TCL_ERROR;
                }

                if (objc==2)
                    mname=asyncautoname(buf);
                else
                    mname=Tcl_GetString(objv[2]);
                
                Ns_MutexLock(&da_lock);
                if ((he=Tcl_CreateHashEntry(&hash,mname,&new))==NULL)
                {
                    Ns_MutexUnlock(&da_lock);
                    return TCL_ERROR;
                }
                if (new)
                {
                    dqe_AsyncData *ad;
                    if ((ad=adCreate())!=NULL)
                    {
                        ad->da_Interp=interp;
                        ad->da_AsyncHandler=Tcl_AsyncCreate((Tcl_AsyncProc *) adEval,(ClientData) ad);
                        Tcl_SetHashValue(he,ad);
                    }
                    else
                    {
                        Tcl_AppendResult(interp,"Memory allocation error",NULL);
                        Tcl_DeleteHashEntry(he);
                        Ns_MutexUnlock(&da_lock);
                        return(TCL_ERROR);
                    }
                }
                else
                {
                    Tcl_AppendResult(interp,"Entry \"",mname,"\" already exists",NULL);
                    Ns_MutexUnlock(&da_lock);
                    return TCL_ERROR;
                }
                Tcl_SetObjResult(interp,Tcl_NewStringObj(mname,-1));
                Ns_MutexUnlock(&da_lock);
                return TCL_OK;
            }
            break;
        
        case C_DELETE:
            {
                if (objc!=3)
                {
                    Tcl_WrongNumArgs(interp,2,objv,"name");
                    return TCL_ERROR;
                }
                Ns_MutexLock(&da_lock);
                if ((he=Tcl_FindHashEntry(&hash,Tcl_GetString(objv[2])))==NULL)
                {
                    Tcl_AppendResult(interp,"Entry \"",Tcl_GetString(objv[2]),"\" does not exist",NULL);
                    Ns_MutexUnlock(&da_lock);
                    return TCL_ERROR;
                }
                adDelete(Tcl_GetHashValue(he));
                Tcl_DeleteHashEntry(he);
                Ns_MutexUnlock(&da_lock);
                return TCL_OK;
            }
            break;

        case C_COMMAND:
            {
                dqe_AsyncData *ad;
                if (objc!=4)
                {
                    Tcl_WrongNumArgs(interp,2,objv,"name command");
                    return TCL_ERROR;
                }
                Ns_MutexLock(&da_lock);
                if ((he=Tcl_FindHashEntry(&hash,Tcl_GetString(objv[2])))==NULL)
                {
                    Tcl_AppendResult(interp,"Entry \"",Tcl_GetString(objv[2]),"\" does not exist",NULL);
                    Ns_MutexUnlock(&da_lock);
                    return TCL_ERROR;
                }
                if ((ad=(dqe_AsyncData *) Tcl_GetHashValue(he))!=NULL)
                {
                    adSetCmd(ad,Tcl_GetString(objv[3]));
                }
                Ns_MutexUnlock(&da_lock);
                return TCL_OK;
                
            }
            break;

        case C_ADD:
            {
                dqe_AsyncData *ad;
                if (objc!=4)
                {
                    Tcl_WrongNumArgs(interp,2,objv,"name params");
                    return TCL_ERROR;
                }
                Ns_MutexLock(&da_lock);
                if ((he=Tcl_FindHashEntry(&hash,Tcl_GetString(objv[2])))==NULL)
                {
                    Tcl_AppendResult(interp,"Entry \"",Tcl_GetString(objv[2]),"\" does not exist",NULL);
                    Ns_MutexUnlock(&da_lock);
                    return TCL_ERROR;
                }
                if ((ad=(dqe_AsyncData *) Tcl_GetHashValue(he))!=NULL)
                {
                    adAddData(ad,Tcl_GetString(objv[3]));
                }
                Tcl_AsyncMark(ad->da_AsyncHandler);
                Ns_MutexUnlock(&da_lock);
                return TCL_OK;
            }
            break;

        default:
            Tcl_AppendResult(interp,"unimplemented",NULL);
            return TCL_ERROR;
            break;
    }
    return TCL_OK;
}
/* }}} */
static int dqe_Async_TclInit(Tcl_Interp *interp, ClientData oc) /* {{{ */
{
    Tcl_CreateObjCommand(interp,"dqe_async",(Tcl_ObjCmdProc *) AsyncCmd,(ClientData) oc,NULL);
    return TCL_OK;
}
/* }}} */
void dqe_Async_Init(char *server, char *module) /* {{{ */
{
    Ns_MutexInit(&da_lock);
    Ns_TclInitInterps(server,(Ns_TclInterpInitProc *) dqe_Async_TclInit,NULL);
    Tcl_InitHashTable(&hash,TCL_STRING_KEYS);
    Ns_Log(Notice,"%s::async",server);
}
/* }}} */

