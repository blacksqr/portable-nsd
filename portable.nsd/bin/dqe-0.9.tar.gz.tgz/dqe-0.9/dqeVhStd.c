#include "dqe.h"
#include "dqeVhStd.h"
#include <sys/stat.h>

#define DHCBUFSIZE 1024
#define FHCBUFSIZE 1024

static void dhc_free(struct dqe_VhStd_DHC *dhc) /* {{{ */
{
    dhc->refcount--;
    if (dhc->refcount<=0)
    {
        Ns_SetFree(dhc->set_match);
        Ns_Free(dhc);
    }
}
/* }}} */
static struct dqe_VhStd_DHC *dhc_get(struct dqe_VhStd_OpCtx *oc, DqeVh_UrlQuery *q) /* {{{ */
{
    struct stat xst;
    char buf[DHCBUFSIZE],*filebuf;
    Ns_Entry *ent;
    int new,reset=0,setsize=sizeof(struct dqe_VhStd_DHC)+sizeof(struct Ns_Set);
    struct dqe_VhStd_DHC *dhc;
    
    snprintf(buf,sizeof(buf),"%s%s",q->pageroot,oc->rewritesfile);
    if (stat(buf,&xst)!=0)
        return(NULL);

    ent=Ns_CacheCreateEntry(oc->domainhelpercache,q->domain,&new);
    if (new)
    {
        dhc=Ns_Malloc(sizeof(struct dqe_VhStd_DHC));
        dhc->refcount=2;
        dhc->set_match=Ns_SetCreate(buf);
        reset=1;
    }
    else
    {
        dhc=Ns_CacheGetValue(ent);
        if ((xst.st_size!=dhc->file_size)||(xst.st_mtime!=dhc->file_mtime))
        {
            Ns_SetFree(dhc->set_match);
            dhc->set_match=Ns_SetCreate(NULL);
            reset=1;
        }
        dhc->refcount++;   
    }
    if (reset)
    {
        int glength,dlength,i,ok,fd;
        Tcl_Obj *globalobj,*typeobj,*dataobj,*miscobj;
        enum { T_MATCH };
        static char *options[] = {
            "match",
            NULL };
        int option;

        dhc->file_size=xst.st_size;
        dhc->file_mtime=xst.st_mtime;
        
        if ((fd=open(buf,O_RDONLY))>=0)
        {
            filebuf=Ns_Malloc(xst.st_size+1);
            filebuf[read(fd,filebuf,xst.st_size)]=0;
            globalobj=Tcl_NewStringObj(filebuf,xst.st_size);
            Ns_Free(filebuf);
            close(fd);
            if (Tcl_ListObjLength(NULL,globalobj,&glength)==TCL_OK)
            {
                Tcl_IncrRefCount(globalobj);
                for (i=0;i<glength;i+=2)
                {
                    ok=1;
                    if (Tcl_ListObjIndex(NULL,globalobj,i+0,&typeobj)!=TCL_OK)
                        ok=0;
                    if (Tcl_ListObjIndex(NULL,globalobj,i+1,&dataobj)!=TCL_OK)
                        ok=0;
                    if (ok)
                        if (Tcl_GetIndexFromObj(NULL,typeobj,options,"",0,&option)!=TCL_OK)
                            ok=0;

                    if (ok)
                        if (Tcl_ListObjLength(NULL,dataobj,&dlength)!=TCL_OK)
                            ok=0;
                    if (ok)
                    {
                        switch (option)
                        {
                            case T_MATCH:
                            {
                                char *mdom,*murl,*nurl;
                                ok=0;
                                if (dlength==3)
                                {
                                    if (Tcl_ListObjIndex(NULL,dataobj,0,&miscobj)==TCL_OK)
                                    {
                                        mdom=Tcl_GetString(miscobj);
                                        if (Tcl_ListObjIndex(NULL,dataobj,1,&miscobj)==TCL_OK)
                                        {
                                            murl=Tcl_GetString(miscobj);
                                            if (Tcl_ListObjIndex(NULL,dataobj,2,&miscobj)==TCL_OK)
                                            {
                                                nurl=Tcl_GetString(miscobj);
                                                ok=1;
                                            }
                                        }
                                    }
                                }
                                if (ok)
                                {
                                    snprintf(buf,sizeof(buf),"%s:%s",mdom,murl);
                                    Ns_SetPut(dhc->set_match,buf,nurl);
                                    setsize+=strlen(buf)+strlen(nurl)+16;
                                }
                                break;
                            }
                        }
                    }
                    else
                    {
                        Ns_Log(Error,"%s: error in entry %d",buf,(i/2)+1);
                    }
                }
                Tcl_DecrRefCount(globalobj);
            }
            else
                Ns_Log(Error,"Error while parsing DHC file: %s",buf);
            dhc->refcount++;
            Ns_CacheSetValueSz(ent,dhc,setsize);
        }
        else
        {
            if (new)
            {
                Ns_CacheDeleteEntry(ent);
                dhc_free(ent);
            }
        }
    }
    return(dhc);
}
/* }}} */

static void fhc_free(struct dqe_VhStd_FHC *fhc) /* {{{ */
{
    fhc->refcount--;
    if (fhc->refcount<=0)
    {
        Ns_SetFree(fhc->set_match);
        Ns_Free(fhc);
    }
}
/* }}} */
static struct dqe_VhStd_FHC *fhc_get(struct dqe_VhStd_OpCtx *oc, DqeVh_FilterQuery *q) /* {{{ */
{
    struct stat xst;
    char buf[FHCBUFSIZE],*filebuf;
    Ns_Entry *ent;
    int new,reset=0,setsize=sizeof(struct dqe_VhStd_FHC)+sizeof(struct Ns_Set);
    struct dqe_VhStd_FHC *fhc;
    
    snprintf(buf,sizeof(buf),"%s%s",q->pageroot,oc->filtersfile);
    if (stat(buf,&xst)!=0)
        return(NULL);

    ent=Ns_CacheCreateEntry(oc->filterhelpercache,q->domain,&new);
    if (new)
    {
        fhc=Ns_Malloc(sizeof(struct dqe_VhStd_FHC));
        fhc->refcount=2;
        fhc->set_match=Ns_SetCreate(buf);
        reset=1;
    }
    else
    {
        fhc=Ns_CacheGetValue(ent);
        if ((xst.st_size!=fhc->file_size)||(xst.st_mtime!=fhc->file_mtime))
        {
            Ns_SetFree(fhc->set_match);
            fhc->set_match=Ns_SetCreate(NULL);
            reset=1;
        }
        fhc->refcount++;   
    }
    if (reset)
    {
        int glength,dlength,i,ok,fd;
        Tcl_Obj *globalobj,*typeobj,*dataobj,*miscobj;
        enum { T_MATCH };
        static char *options[] = {
            "match",
            NULL };
        int option;

        fhc->file_size=xst.st_size;
        fhc->file_mtime=xst.st_mtime;
        
        if ((fd=open(buf,O_RDONLY))>=0)
        {
            filebuf=Ns_Malloc(xst.st_size+1);
            filebuf[read(fd,filebuf,xst.st_size)]=0;
            globalobj=Tcl_NewStringObj(filebuf,xst.st_size);
            Ns_Free(filebuf);
            close(fd);
            if (Tcl_ListObjLength(NULL,globalobj,&glength)==TCL_OK)
            {
                Tcl_IncrRefCount(globalobj);
                for (i=0;i<glength;i+=2)
                {
                    ok=1;
                    if (Tcl_ListObjIndex(NULL,globalobj,i+0,&typeobj)!=TCL_OK)
                        ok=0;
                    if (Tcl_ListObjIndex(NULL,globalobj,i+1,&dataobj)!=TCL_OK)
                        ok=0;
                    if (ok)
                        if (Tcl_GetIndexFromObj(NULL,typeobj,options,"",0,&option)!=TCL_OK)
                            ok=0;

                    if (ok)
                        if (Tcl_ListObjLength(NULL,dataobj,&dlength)!=TCL_OK)
                            ok=0;
                    if (ok)
                    {
                        switch (option)
                        {
                            case T_MATCH:
                            {
                                char *mdom,*murl,*nurl;
                                ok=0;
                                if (dlength==3)
                                {
                                    if (Tcl_ListObjIndex(NULL,dataobj,0,&miscobj)==TCL_OK)
                                    {
                                        mdom=Tcl_GetString(miscobj);
                                        if (Tcl_ListObjIndex(NULL,dataobj,1,&miscobj)==TCL_OK)
                                        {
                                            murl=Tcl_GetString(miscobj);
                                            if (Tcl_ListObjIndex(NULL,dataobj,2,&miscobj)==TCL_OK)
                                            {
                                                nurl=Tcl_GetString(miscobj);
                                                ok=1;
                                            }
                                        }
                                    }
                                }
                                if (ok)
                                {
                                    snprintf(buf,sizeof(buf),"%s:%s",mdom,murl);
                                    Ns_SetPut(fhc->set_match,buf,nurl);
                                    setsize+=strlen(buf)+strlen(nurl)+16;
                                }
                                break;
                            }
                        }
                    }
                    else
                    {
                        Ns_Log(Error,"%s: error in entry %d",buf,(i/2)+1);
                    }
                }
                Tcl_DecrRefCount(globalobj);
            }
            else
                Ns_Log(Error,"Error while parsing FHC file: %s",buf);
            fhc->refcount++;
            Ns_CacheSetValueSz(ent,fhc,setsize);
        }
        else
        {
            if (new)
            {
                Ns_CacheDeleteEntry(ent);
                fhc_free(ent);
            }
        }
    }
    return(fhc);
}
/* }}} */

static int handle_domain_tcl(struct dqe_VhStd_OpCtx *oc, DqeVh_DomainQuery *q) /* {{{ */
{
    Tcl_Obj *o[5];
    Tcl_Interp *interp;
    struct stat xst;
    Ns_Conn *c;
    int fd;
    
    if ((c=Ns_TclGetConn(NULL))!=NULL)
        interp=Ns_GetConnInterp(c);
    else
        interp=Ns_TclAllocateInterp(oc->servername);

    if (stat(oc->vhostsfilename,&xst)!=0)
        return DQEVH_CB_OK;

    if ((oc->vhosts_mtime!=xst.st_mtime)||(oc->vhosts_size!=xst.st_size))
    {
        oc->vhosts_mtime=xst.st_mtime;
        oc->vhosts_size=xst.st_size;
        if (oc->vhostsfile!=NULL)
            Ns_Free(oc->vhostsfile);
        
        if ((fd=open(oc->vhostsfilename,O_RDONLY))>=0)
        {
            oc->vhostsfile=Ns_Malloc(oc->vhosts_size+1);
            oc->vhostsfile[read(fd,oc->vhostsfile,oc->vhosts_size)]=0;
            close(fd);
        }
        else
        {
            oc->vhostsfile=NULL;
            return DQEVH_CB_OK;
        }
        
    }
    
    o[0]=Tcl_NewStringObj("dqevh::main",15);
    o[1]=Tcl_NewStringObj(q->domain,-1);
    o[2]=Tcl_NewStringObj(q->path,-1);
    o[3]=Tcl_NewStringObj(oc->vhostsfile,oc->vhosts_size);
    Tcl_IncrRefCount(o[0]); 
    Tcl_IncrRefCount(o[1]);
    Tcl_IncrRefCount(o[2]);
    Tcl_IncrRefCount(o[3]);
    if (Tcl_EvalObjv(interp,4,o,0)==TCL_OK)
        strncpy(q->path,Tcl_GetStringResult(interp),(DQEVH_PATH_SIZE-1));
    else
        Ns_TclLogError(interp);
    Tcl_DecrRefCount(o[0]); 
    Tcl_DecrRefCount(o[1]);
    Tcl_DecrRefCount(o[2]);
    Tcl_DecrRefCount(o[3]);
    if (!c)
        Ns_TclDeAllocateInterp(interp);
    return DQEVH_CB_OK;
}
/* }}} */
static int handle_url_rewrite(struct dqe_VhStd_OpCtx *oc, DqeVh_UrlQuery *q) /* {{{ */
{
    char buf[DQEVH_PATH_SIZE*2];
    int ssize,i,slen;
    struct dqe_VhStd_DHC *dhc;
    Ns_CacheLock(oc->domainhelpercache);
    dhc=dhc_get(oc,q);
    Ns_CacheUnlock(oc->domainhelpercache);
    if (dhc)
    {
        ssize=Ns_SetSize(dhc->set_match);
        if (ssize>0)
        {
            slen=strlen(q->domainnowww);
            if (slen>=(sizeof(buf)-3))
                slen=sizeof(buf)-4;
            for (i=0;i<slen;i++)
                buf[i]=tolower(q->domainnowww[i]);
            buf[slen++]=':';
            strncpy(buf+slen,q->url,sizeof(buf)-slen-1);
            buf[sizeof(buf)-1]=0;
            for (i=0;i<ssize;i++)
            {
                if (Tcl_StringMatch(buf,Ns_SetKey(dhc->set_match,i)))
                    snprintf(q->filename,DQEVH_PATH_SIZE,"%s%s",q->pageroot,Ns_SetValue(dhc->set_match,i));
            }
        }
        Ns_CacheLock(oc->domainhelpercache);
        dhc_free(dhc);
        Ns_CacheUnlock(oc->domainhelpercache);
    }
    return DQEVH_CB_OK;
}
/* }}} */
static int handle_url_filter(struct dqe_VhStd_OpCtx *oc, DqeVh_FilterQuery *q) /* {{{ */
{
    int ssize,i,slen;
    struct dqe_VhStd_FHC *fhc;
    Ns_CacheLock(oc->filterhelpercache);
    fhc=fhc_get(oc,q);
    Ns_CacheUnlock(oc->filterhelpercache);
    if (fhc)
    {
        ssize=Ns_SetSize(fhc->set_match);
        if (ssize>0)
        {
            for (i=0;i<ssize;i++)
            {
                if (Tcl_StringMatch(q->domurl,Ns_SetKey(fhc->set_match,i)))
                {
                    Ns_ConnRedirect(q->conn,Ns_SetValue(fhc->set_match,i));
                    q->dobreak=1;
                    break;
                }
            }
        }
        Ns_CacheLock(oc->filterhelpercache);
        fhc_free(fhc);
        Ns_CacheUnlock(oc->filterhelpercache);
    }
    return DQEVH_CB_OK;
}
/* }}} */

void dqe_VhStd_Init(char *server, char *module) /* {{{ */
{
    struct dqe_VhStd_OpCtx *oc;
    char *path;
    if ((oc=Ns_Malloc(sizeof(struct dqe_VhStd_OpCtx)))!=NULL)
    {
        if ((path=Ns_ConfigGetPath(server,module,"vh",NULL))!=NULL)
        {
            if (Ns_ConfigGetInt(path,"helpercachesize",&oc->helpercachesize)!=NS_TRUE)
                oc->helpercachesize=131072;
            oc->rewritesfile=Ns_ConfigGetValue(path,"rewrites");
            if (!oc->rewritesfile)
                oc->rewritesfile="/.rewrites";
            oc->filtersfile=Ns_ConfigGetValue(path,"filters");
            if (!oc->filtersfile)
                oc->filtersfile="/.filters";
            oc->vhostsfilename=Ns_ConfigGetValue(path,"vhostsfile");
            if (!oc->vhostsfilename)
                oc->vhostsfilename="/usr/local/aolserver/vhosts";
        }
        else
        {
            oc->helpercachesize=131072;
            oc->rewritesfile="/.rewrites";
            oc->filtersfile="/.filters";
            oc->vhostsfilename="/usr/local/aolserver/vhosts";
        }
        oc->helpercachesize=1;
        oc->servername=server;
        oc->domainhelpercache=Ns_CacheCreateSz("dqevhstd_domainhelper",TCL_STRING_KEYS,oc->helpercachesize,(Ns_Callback *) dhc_free);
        oc->filterhelpercache=Ns_CacheCreateSz("dqevhstd_filterhelper",TCL_STRING_KEYS,oc->helpercachesize,(Ns_Callback *) fhc_free);
        DqeVh_DomainAddHandler(DqeVh_Ctx(server),0,(DqeVh_Callback *) handle_domain_tcl,oc);
        DqeVh_UrlAddHandler(DqeVh_Ctx(server),0,(DqeVh_Callback *) handle_url_rewrite,oc);
        DqeVh_FilterAddHandler(DqeVh_Ctx(server),0,(DqeVh_Callback *) handle_url_filter,oc);
        oc->vhosts_size=-1;
        oc->vhosts_mtime=0;
        oc->vhostsfile=NULL;
    }
}
/* }}} */


