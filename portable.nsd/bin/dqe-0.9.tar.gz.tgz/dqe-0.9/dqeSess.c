#include "dqe.h"
#include "dqeSess.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

static void ce_mkname(struct dqe_Sess_OpCtx *oc, char *buf, char *sid) /* {{{ */
{
    char c;
    
    sprintf(buf,"%s/",oc->sessiondir);
    buf+=strlen(buf);
    while ((c=(*sid++))!=0)
    {
        if (c=='/')
            c='_';
        *buf++=c;
    }
    *buf=0;
}
/* }}} */
static struct dqe_Sess_CacheEntry *ce_init(struct dqe_Sess_OpCtx *oc, char *sid, struct dqe_SessId *id) /* {{{ */
{
    char buf[4096],*xbuf,*pos,*chr,*end,*key=NULL;
    struct dqe_Sess_CacheEntry *rc;
    int fd,size;
    
    if ((rc=Ns_Malloc(sizeof(struct dqe_Sess_CacheEntry)))!=NULL)
    {
        memcpy(rc->sid64,sid,DQE_SESSID_ENSIZE);
        rc->refcount=1;
        rc->sid64[DQE_SESSID_ENSIZE]=0;
        memcpy(&rc->sid,id,sizeof(struct dqe_SessId));
        rc->keys=Ns_SetCreate("");
        rc->oc=oc;

        ce_mkname(oc,buf,sid);

        Ns_MutexInit(&rc->mutex);
#ifdef DEBUG
        Ns_Log(Debug,"ce_init(): filename='%s'",buf);
#endif
        if ((fd=open(buf,O_RDONLY))>=0)
        {
            if ((size=lseek(fd,0,SEEK_END))>=0)
            {
                lseek(fd,0,SEEK_SET);
                if ((xbuf=Ns_Malloc(size+1))!=NULL)
                {
                    xbuf[size]=0;
                    read(fd,xbuf,size);
                    
                    end=xbuf+size;
                    pos=xbuf;
                    while (pos<end)
                    {
                        if (!key)
                            key=pos;
                        else
                        {
#ifdef DEBUG
                            Ns_Log(Debug,"%s: '%s'='%s'",buf,key,pos);
#endif
                            Ns_SetPut(rc->keys,key,pos);
                            key=NULL;
                        }

                        pos+=strlen(pos)+1;
                    }
                    
                    Ns_Free(xbuf);
                }
            }
            close(fd);
        }
    }
    return(rc);
}
/* }}} */
static __inline void ce_ref(struct dqe_Sess_CacheEntry *e) /* {{{ */
{
    e->refcount++;
}
/* }}} */
static __inline void ce_deref(struct dqe_Sess_CacheEntry *e) /* {{{ */
{
    int fd;
    int i,len;
    char *str;
    
    e->refcount--;
#ifdef DEBUG
    Ns_Log(Debug,"Cleaning up session '%s' - refcount is %d",e->sid64,e->refcount);
#endif
    if (e->refcount<=0)
    {
        char buf[4096];
        ce_mkname(e->oc,buf,e->sid64);
#ifdef DEBUG
        Ns_Log(Debug,"Cleaning up session '%s' - writing",e->sid64);
#endif
        if (Ns_SetSize(e->keys)>0)
        {
            if ((fd=open(buf,O_WRONLY|O_CREAT|O_TRUNC,0700))>=0)
            {
                len=Ns_SetSize(e->keys);
                for (i=0;i<len;i++)
                {
                    str=Ns_SetKey(e->keys,i);
                    write(fd,str,strlen(str)+1);
                    str=Ns_SetValue(e->keys,i);
                    write(fd,str,strlen(str)+1);
                }
                close(fd);
            }
        }
        else
        {
            /* we do not store empty sessions */
            remove(buf);
        }
#ifdef DEBUG
        Ns_Log(Debug,"Cleaning up session '%s' - freeing set",e->sid64);
#endif
        Ns_SetFree(e->keys);
#ifdef DEBUG
        Ns_Log(Debug,"Cleaning up session '%s' - freeing memory",e->sid64);
#endif
        /* TODO: investigate if this mutex could be incidentally in use */
        Ns_MutexDestroy(&e->mutex);
        Ns_Free(e);
#ifdef DEBUG
        Ns_Log(Debug,"Cleaning up session '%s'",e->sid64);
#endif
    }
}
/* }}} */

static struct dqe_Sess_Tls *tls_init(struct dqe_Sess_OpCtx *oc) /* {{{ */
{
    struct dqe_Sess_Tls *rc=NULL;
    Ns_GetThreadLocalStorage(&oc->connlocal,(void **) &rc);
    if (rc==NULL)
    {
#ifdef DEBUG
        Ns_Log(Debug,"tls_init called - empty");
#endif
        if ((rc=Ns_Malloc(sizeof(struct dqe_Sess_Tls)))!=NULL)
        {
            /* initialize */
            rc->entry=NULL;
            rc->tclset[0]=0;
            rc->locked=0;
            Ns_SetThreadLocalStorage(&oc->connlocal,rc);
        }
    }
    else
    {
#ifdef DEBUG
        Ns_Log(Debug,"tls_init called with %p",rc);
#endif
    }
    return rc;
}
/* }}} */
static void tls_free(struct dqe_Sess_Tls *tls) /* {{{ */
{
#ifdef DEBUG
    Ns_Log(Debug,"tls_free called in %08x",Ns_ThreadId());
#endif
    Ns_Free(tls);
}
/* }}} */
static void free_atexit(struct dqe_Sess_OpCtx *oc) /* {{{ */
{
    Ns_Log(Debug,"Free'ing sessions at exit");
    Ns_MutexLock(&oc->mutex);
    Ns_CacheFlush(oc->sessions);
    Ns_MutexUnlock(&oc->mutex);
}
/* }}} */

static void flush_old_sessions(struct dqe_Sess_OpCtx *oc) /* {{{ */
{
    DIR *dir;
    struct dirent *de;
    struct stat statbuf;
    char buf[4096];
    Ns_Time time;
    time_t ftime;

    Ns_GetTime(&time);
    if ((dir=opendir(oc->sessiondir))!=NULL)
    {
        de=readdir(dir);
        while (de!=NULL)
        {
            sprintf(buf,"%s/%s",oc->sessiondir,de->d_name);
            de=readdir(dir);

            stat(buf,&statbuf);
            /* we're only interested in plain files */
            if (!S_ISREG(statbuf.st_mode))
                continue;
            ftime=statbuf.st_mtime;
            if (ftime<statbuf.st_atime)
                 ftime=statbuf.st_atime;

            /* remove obsoleted sessions */
            if ((time.sec-ftime)>oc->sessionfileexpiration)
                remove(buf);
        }
        closedir(dir);
    }
}
/* }}} */

static void free_daily(struct dqe_Sess_OpCtx *oc, int schedid) /* {{{ */
{
    Ns_Log(Debug,"Free'ing sessions (daily synchronization)");
    Ns_MutexLock(&oc->mutex);
    Ns_CacheFlush(oc->sessions);
    Ns_MutexUnlock(&oc->mutex);
    /* flushing old sessions */
    Ns_Log(Debug,"Flushing old sessions");
    flush_old_sessions(oc);
}
/* }}} */

static void initsession_decode(char *sid, struct dqe_SessId *id) /* {{{ */
{
    char decodebuf[DQE_SESSID_SIZE+4];
    Ns_HtuuDecode(sid,decodebuf,DQE_SESSID_SIZE);
    memcpy(id,decodebuf,DQE_SESSID_SIZE);
}
/* }}} */
static int initsession_getcookie(struct dqe_Sess_OpCtx *oc, char *sid, struct dqe_SessId *id) /* {{{ */
{
    char *setval;
    int i,setlen,rc=0;
    Ns_Set *headers;
    
    sid[0]=0;
    if ((headers=Ns_ConnHeaders(Ns_GetConn()))!=NULL)
    {
        setlen=Ns_SetSize(headers);
        for (i=0;i<setlen;i++)
        {
            if (!strcmp(Ns_SetKey(headers,i),"Cookie"))
            {
                setval=Ns_SetValue(headers,i);
                if (!memcmp(setval,DQE_SESSION_COOKIEPREFIX,DQE_SESSION_COOKIESTRLEN))
                {
                    memcpy(sid,setval+DQE_SESSION_COOKIESTRLEN,DQE_SESSID_ENSIZE);
                    sid[DQE_SESSID_ENSIZE]=0;
                    rc=1;
                }
            }
        }
    }
    if (rc)
    {
        initsession_decode(sid,id);
    }
    return(rc);
}
/* }}} */
static void initsession_mkcookie(char *sid, struct dqe_SessId *id) /* {{{ */
{
    Ns_Time t;
    Ns_GetTime(&t);
    id->sec=t.sec;
    id->usec=t.usec;
    id->pid=Ns_InfoPid();
    id->tid=Ns_ThreadId();
    Ns_HtuuEncode((char *) id,DQE_SESSID_SIZE,sid);
    sid[DQE_SESSID_ENSIZE]=0;
}
/* }}} */
static void initsession_setcookie(char *sid, int timeout) /* {{{ */
{
    Ns_Set *headers;
    Ns_DString ds;
    time_t exptime;
    Ns_Time ctime;

    if ((headers=Ns_ConnOutputHeaders(Ns_GetConn()))!=NULL)
    {
        Ns_DStringInit(&ds);
        Ns_DStringNAppend(&ds,DQE_SESSION_COOKIEPREFIX,DQE_SESSION_COOKIESTRLEN);
        Ns_DStringNAppend(&ds,sid,DQE_SESSID_ENSIZE);
        Ns_DStringAppend(&ds,"; path=/");
        if (timeout>0)
        {
            Ns_GetTime(&ctime);
            exptime=ctime.sec+timeout;
            Ns_DStringAppend(&ds,"; expires=");
            Ns_HttpTime(&ds,&exptime);
        }
        Ns_SetPut(headers,"Set-Cookie",Ns_DStringValue(&ds));
        // Ns_Log(Debug,"Cookie: '%s'",Ns_DStringValue(&ds));
        Ns_DStringFree(&ds);
    }
}
/* }}} */

static void conn_cleanup(struct dqe_Sess_OpCtx *oc) /* {{{ */
{
    struct dqe_Sess_Tls *tls;
    Ns_MutexLock(&oc->mutex);
    tls=tls_init(oc);
#ifdef DEBUG
    Ns_Log(Debug,"Cleaning up connection (entry=%p)",tls->entry);
#endif
    if (tls->entry)
    {
        if (tls->locked)
        {
#ifdef DEBUG
            Ns_Log(Debug,"Unlocking session '%s'",tls->entry->sid64);
#endif
            Ns_MutexUnlock(&tls->entry->mutex);
            tls->locked=0;
        }
        ce_deref(tls->entry);

        tls->entry=NULL;
        if ((tls->tclset[0])&&(tls->interp!=NULL))
        {
#ifdef DEBUG
            Ns_Log(Debug,"Free'ing ns_set '%s'",tls->tclset);
#endif
            Ns_TclFreeSet(tls->interp,tls->tclset);
            tls->interp=NULL;
            tls->tclset[0]=0;
        }
    }
#ifdef DEBUG
    Ns_Log(Debug,"Cleaning up connection done");
#endif
    Ns_MutexUnlock(&oc->mutex);
}
/* }}} */

static struct dqe_Sess_CacheEntry *initsession(Tcl_Interp *interp, struct dqe_Sess_OpCtx *oc, /* {{{ */
        char *newsid, int timeout, 
        int sw_allow_getcookie,
        int sw_allow_newcookie,
        int sw_always_setcookie)
{
    enum {CM_UNKNOWN, CM_GETCOOKIE, CM_NEWCOOKIE, CM_FORCECOOKIE};
    char sid[DQE_SESSID_ENSIZE+1];
    struct dqe_SessId sessid;
    struct dqe_Sess_CacheEntry *e=NULL;
    struct dqe_Sess_Tls *tls;
    int new,cookiemethod=CM_UNKNOWN;
    Ns_Entry *ce;

    sid[0]=0;

    /* get SID from cookie */
    if (sw_allow_getcookie)
    {
        if (initsession_getcookie(oc,sid,&sessid))
            cookiemethod=CM_GETCOOKIE;
#ifdef DEBUG
        Ns_Log(Debug,"After getcookie: '%s'",sid);
#endif
    }
    if ((sw_allow_newcookie)&&(!sid[0]))
    {
        initsession_mkcookie(sid,&sessid);
        cookiemethod=CM_NEWCOOKIE;
#ifdef DEBUG
        Ns_Log(Debug,"After mkcookie: '%s'",sid);
#endif
    }
    if (newsid)
    {
        memcpy(sid,newsid,DQE_SESSID_ENSIZE);
        sid[DQE_SESSID_ENSIZE]=0;
        initsession_decode(sid,&sessid);
        cookiemethod=CM_FORCECOOKIE;
#ifdef DEBUG
        Ns_Log(Debug,"Forcing new sid: '%s'",sid);
#endif
    }
    
    if (!sid[0])
        return(NULL);

    if ((cookiemethod!=CM_GETCOOKIE)||(sw_always_setcookie))
    {
#ifdef DEBUG
        Ns_Log(Debug,"Setting cookie");
#endif
        initsession_setcookie(sid,timeout);
    }
    else
    {
#ifdef DEBUG
        Ns_Log(Debug,"Not setting cookie!");
#endif
    }

    ce=Ns_CacheCreateEntry(oc->sessions,(char *) &sessid,&new);
    if (new)
    {
        /* we need to initialize the session etry */
        if ((e=ce_init(oc,sid,&sessid))!=NULL)
        {
            Ns_CacheSetValueSz(ce,e,1);
        }
        else
        {
            Ns_CacheDeleteEntry(ce);
        }
    }
    else
    {
        /* the entry already exists - we must increase the reference count */
        e=Ns_CacheGetValue(ce);
    }

    /* allocating e might have failed */
    if (e)
    {
        ce_ref(e);
        if ((tls=tls_init(oc))!=NULL)
        {
            tls->entry=e;
            Ns_TclEnterSet(interp,e->keys,0);
            strcpy(tls->tclset,interp->result);
            tls->interp=interp;
        }
    }

    return(e);
}
/* }}} */
static void freesession(struct dqe_Sess_CacheEntry *e) /* {{{ */
{
    struct dqe_Sess_OpCtx *oc=e->oc;
#ifdef DEBUG
    Ns_Log(Debug,"Free'ing '%s'",e->sid64);
#endif
    ce_deref(e);
}
/* }}} */

/* commands {{{ */
enum {
    C_INIT,
    C_FLUSH,
    C_ENABLED,
    C_SID,
    C_SET,
    C_LOCK,
    C_UNLOCK,
    C_MAX
};
static char *c_idx[] = {
    "init",
    "flush",
    "enabled",
    "sid",
    "set",
    "lock",
    "unlock",
    NULL
};
/* }}} */
static int dqe_SessCmd(struct dqe_Sess_OpCtx *oc, Tcl_Interp *interp, int objc, Tcl_Obj *CONST objv[]) /* {{{ */
{
    int cmd,rc=TCL_OK;
    if (objc<2)
    {
        Tcl_WrongNumArgs(interp,1,objv,"command ?args?");
        return TCL_ERROR;
    }
    if (Tcl_GetIndexFromObj(interp,objv[1],c_idx,"option",0,&cmd)!=TCL_OK)
        return TCL_ERROR;
    
    switch (cmd)
    {
        case C_INIT: /* {{{ */
        {
            static char *switches[]={ "-expires", "-sid", "-mode", NULL };
            static char *sw_mode[]={ "default", "allownew", "random", NULL };
            enum { SW_INIT_EXPIRES, SW_INIT_SID, SW_INIT_MODE, SW_INIT_MAX };
            enum { SW_MODE_DEFAULT, SW_MODE_ALLOWNEW, SW_MODE_RANDOM };
            struct dqe_Sess_CacheEntry *e;
            char *sid=NULL;
            int expires=0;
            int mode=SW_MODE_DEFAULT;
            int sw_allow_getcookie,sw_allow_newcookie,sw_always_setcookie;
            int i;
            
            Ns_MutexLock(&oc->mutex);
            if ((objc%2)!=0)
            {
                Tcl_WrongNumArgs(interp,2,objv,"?-param value ?-param value??");
                rc=TCL_ERROR; goto exit_unlock;
            }
            
            for (i=2;i<objc;i++)
            {
                if (Tcl_GetIndexFromObj(interp,objv[i],switches,"switch",0,&cmd)!=TCL_OK)
                {
                    rc=TCL_ERROR; goto exit_unlock;
                }
                i++;
                switch (cmd)
                {
                    case SW_INIT_EXPIRES:
                        if (Tcl_GetIntFromObj(interp,objv[i],&expires)!=TCL_OK)
                        {
                            rc=TCL_ERROR; goto exit_unlock;
                        }
                        if (expires<0)
                        {
                            Tcl_SetResult(interp,"Expiration value must be non-negative",TCL_STATIC);
                            rc=TCL_ERROR; goto exit_unlock;
                        }
                        break;
                    case SW_INIT_SID:
                        sid=Tcl_GetString(objv[i]);
                        break;
                    case SW_INIT_MODE:
                        if (Tcl_GetIndexFromObj(interp,objv[i],sw_mode,"mode",0,&mode)!=TCL_OK)
                        {
                            rc=TCL_ERROR; goto exit_unlock;
                        }
                        break;
                }
            }
            switch (mode)
            {
                case SW_MODE_RANDOM:
                    sw_allow_getcookie=0;
                    sw_allow_newcookie=1;
                    sw_always_setcookie=1;
                    break;
                case SW_MODE_ALLOWNEW:
                    sw_allow_getcookie=1;
                    sw_allow_newcookie=1;
                    sw_always_setcookie=0;
                    break;
                default:
                    if (sid)
                    {
                        sw_allow_getcookie=0;
                        sw_allow_newcookie=0;
                        sw_always_setcookie=1;
                    }
                    else
                    {
                        sw_allow_getcookie=1;
                        sw_allow_newcookie=0;
                        sw_always_setcookie=0;
                    }
                    break;
            }
            e=initsession(interp,oc,sid,expires,sw_allow_getcookie,sw_allow_newcookie,sw_always_setcookie);
            goto exit_unlock;
            break;
        }
        /* }}} */
        case C_FLUSH: /* {{{ */
        {
            Ns_CacheFlush(oc->sessions);
            break;
        }
        /* }}} */
        case C_LOCK: case C_UNLOCK: /* {{{ */
        {
            struct dqe_Sess_Tls *tls;
            if ((tls=tls_init(oc))!=NULL)
            {
                if (tls->entry)
                {
                    switch (cmd)
                    {
                        case C_LOCK:
                            if (!tls->locked)
                            {
#ifdef DEBUG
                                Ns_Log(Debug,"Lock'ing '%s'",tls->entry->sid64);
#endif
                                Ns_MutexLock(&tls->entry->mutex);
                                tls->locked=1;
#ifdef DEBUG
                                Ns_Log(Debug,"Locked '%s'",tls->entry->sid64);
#endif
                            }
                            else
                            {
#ifdef DEBUG
                                Ns_Log(Debug,"NOT lock'ing '%s'",tls->entry->sid64);
#endif
                            }
                            break;
                        case C_UNLOCK:
                            if (tls->locked)
                            {
#ifdef DEBUG
                                Ns_Log(Debug,"Unlock'ing '%s'",tls->entry->sid64);
#endif
                                tls->locked=0;
                                Ns_MutexUnlock(&tls->entry->mutex);
#ifdef DEBUG
                                Ns_Log(Debug,"Unlocked '%s'",tls->entry->sid64);
#endif
                            }
                            else
                            {
#ifdef DEBUG
                                Ns_Log(Debug,"NOT unlock'ing '%s'",tls->entry->sid64);
#endif
                            }
                            break;
                    }
                }
                else
                {
                    Tcl_SetResult(interp,"No current session",NULL);
                    rc=TCL_ERROR;
                }
            }
            else
            {
                Tcl_SetResult(interp,"Unable to initialize ThreadLocalStorage",NULL);
                rc=TCL_ERROR;
            }
            break;
        }
        /* }}} */
        case C_SID: /* {{{ */
        {
            struct dqe_Sess_Tls *tls;
            if ((tls=tls_init(oc))!=NULL)
            {
                if (tls->entry)
                {
                    Tcl_SetObjResult(interp,Tcl_NewStringObj(tls->entry->sid64,DQE_SESSID_ENSIZE));
                }
                else
                {
                    Tcl_SetResult(interp,"No current session",NULL);
                    rc=TCL_ERROR;
                }
            }
            else
            {
                Tcl_SetResult(interp,"Unable to initialize ThreadLocalStorage",NULL);
                rc=TCL_ERROR;
            }
            break;
        }
        /* }}} */
        case C_SET: /* {{{ */
        {
            struct dqe_Sess_Tls *tls;
            if ((tls=tls_init(oc))!=NULL)
            {
                if (tls->entry)
                {
                    Tcl_SetObjResult(interp,Tcl_NewStringObj(tls->tclset,-1));
                }
                else
                {
                    Tcl_SetResult(interp,"No current session",NULL);
                    rc=TCL_ERROR;
                }
            }
            else
            {
                Tcl_SetResult(interp,"Unable to initialize ThreadLocalStorage",NULL);
                rc=TCL_ERROR;
            }
            break;
        }
        /* }}} */
        case C_ENABLED: /* {{{ */
        {
            struct dqe_Sess_Tls *tls;
            if ((tls=tls_init(oc))!=NULL)
            {
                if (tls->entry)
                {
                    Tcl_SetObjResult(interp,Tcl_NewBooleanObj(1));
                    rc=TCL_OK;
                }  else  {
                    Tcl_SetObjResult(interp,Tcl_NewBooleanObj(0));
                    rc=TCL_OK;
                }
            }  else  {
                Tcl_SetObjResult(interp,Tcl_NewBooleanObj(0));
                rc=TCL_OK;
            }
            break;
        }
        /* }}} */
        
    }
    return(rc);

exit_unlock:
    Ns_MutexUnlock(&oc->mutex);
    return rc;
}
/* }}} */

static int dqe_Sess_TclInit(Tcl_Interp *interp, struct dqe_Sess_OpCtx *oc) /* {{{ */
{
    Tcl_CreateObjCommand(interp,"dqe_sess",(Tcl_ObjCmdProc *) dqe_SessCmd,oc,NULL);
    return NS_OK;
}
/* }}} */
void dqe_Sess_Init(char *server, char *module) /* {{{ */
{
    struct dqe_Sess_OpCtx *oc;
    char *param,*path;
    if ((oc=Ns_Malloc(sizeof(struct dqe_Sess_OpCtx)))!=NULL)
    {
        if ((path=Ns_ConfigGetPath(server,module,"sessions",NULL))!=NULL)
        {
            param=Ns_ConfigGetValue(path,"directory");
            if (!param)
                param=DQE_SESS_DEFAULT_DIRECTORY;
            oc->sessiondir=param;
            if (Ns_ConfigGetInt(path,"cachesize",&oc->maxcachesize)!=NS_TRUE)
                oc->maxcachesize=DQE_SESS_DEFAULT_CACHESIZE;
            if (Ns_ConfigGetInt(path,"expiration",&oc->sessionfileexpiration)!=NS_TRUE)
                oc->sessionfileexpiration=DQE_SESS_DEFAULT_EXPIRATION;
        }
        else
        {
            oc->sessiondir=DQE_SESS_DEFAULT_DIRECTORY;
            oc->maxcachesize=DQE_SESS_DEFAULT_CACHESIZE;
            oc->sessionfileexpiration=DQE_SESS_DEFAULT_EXPIRATION;
        }

        oc->sessions=Ns_CacheCreateSz("dqe_sess",DQE_SESSID_KEYSIZE,oc->maxcachesize,(Ns_Callback *) freesession);
        Ns_TclInitInterps(server,(Ns_TclInterpInitProc *) dqe_Sess_TclInit,oc);
        Ns_Log(Notice,"%s::Sess loaded (directory is %s)",server,oc->sessiondir);
        Ns_MutexInit(&oc->mutex);
        Ns_RegisterAtExit((Ns_Callback *) free_atexit,oc);
        Ns_AllocThreadLocalStorage(&oc->connlocal,(Ns_Callback *) tls_free);
        Ns_RegisterCleanup((Ns_TraceProc *) conn_cleanup,oc);
        Ns_ScheduleDaily((Ns_SchedProc *) free_daily, oc, 0, 4,30, NULL);
    }
}
/* }}} */


