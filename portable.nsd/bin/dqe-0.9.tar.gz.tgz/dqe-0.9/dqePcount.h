#ifndef DQEPCOUNT_H
#define DQEPCOUNT_H 1

#include "dqe.h"

/* internal data */
struct dqe_Pcount_OpCtx {
    Ns_Mutex mutex;
    // Tcl_HashTable hash;
    Ns_Cache *cache;
};

struct dqe_Pcount_Value {
    Ns_Time starttime;
    int timeid;
    unsigned long ntimes;
    unsigned long ntimed;
    unsigned long totaltime;
};

#define DQE_PCOUNT_BENCH        0x80000000

static int dqe_Pcount_Filter(struct dqe_Pcount_OpCtx *oc, Ns_Conn *conn, int why);
#endif
