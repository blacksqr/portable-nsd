#ifndef DQEDECL_H
#define DQEDECL_H 1

void dqe_Async_Init(char *server, char *module);
void dqe_Cache_Init(char *server, char *module);
void dqe_Chan_Init(char *server, char *module);
void dqe_Enc_Init(char *server, char *module);
void dqe_Parser_Init(char *server, char *module);
void dqe_Pcount_Init(char *server, char *module);
void dqe_Sess_Init(char *server, char *module);
void dqe_Stat_Init(char *server, char *module);
void dqe_Utils_Init(char *server, char *module);
void dqe_Vh_Init(char *server, char *module);
void dqe_VhStd_Init(char *server, char *module);

#endif

