#include "dqe.h"
#include "dqeDecl.h"

int Ns_ModuleVersion = 1;

int Ns_ModuleInit(char *hServer, char *hModule)
{
    dqe_Parser_Init(hServer,hModule);
    dqe_Stat_Init(hServer,hModule);
    dqe_Enc_Init(hServer,hModule);
    dqe_Utils_Init(hServer,hModule);
    dqe_Chan_Init(hServer,hModule);
    dqe_Async_Init(hServer,hModule);
    dqe_Pcount_Init(hServer,hModule);
    dqe_Cache_Init(hServer,hModule);
    dqe_Sess_Init(hServer,hModule);
    dqe_Vh_Init(hServer,hModule);
    dqe_VhStd_Init(hServer,hModule);
    return NS_OK;
}


