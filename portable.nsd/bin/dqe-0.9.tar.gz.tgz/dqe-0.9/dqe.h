#ifndef DQE_H
#define DQE_H 1

#ifndef USE_TCL8X
#define USE_TCL8X
#endif

#include <ns.h>
#include <tcl.h>

/* Vhosting */
#define DQEVH_CB_OK             0
#define DQEVH_CB_BREAK          1

typedef int (DqeVh_Callback) (void *clientdata, void *arg);

#define DQEVH_PATH_SIZE     512
#define DQEVH_HOST_SIZE     128

typedef struct DqeVh_FilterQuery {
    Ns_Conn *conn;
    char *pageroot;
    char *method;
    char *domain;
    char *url;
    char domurl[DQEVH_HOST_SIZE*2];
    int dobreak;
} DqeVh_FilterQuery;

typedef struct DqeVh_DomainQuery {
    char *domain;
    char path[DQEVH_PATH_SIZE];
} DqeVh_DomainQuery;

typedef struct DqeVh_UrlQuery {
    char *domain;
    char *domainnowww;
    char *url;
    char pageroot[DQEVH_PATH_SIZE];
    char filename[DQEVH_PATH_SIZE];
} DqeVh_UrlQuery;

void DqeVh_DomainAddHandler(void *ctx, short priority, DqeVh_Callback *callback, ClientData clientdata);
void DqeVh_UrlAddHandler(void *ctx, short priority, DqeVh_Callback *callback, ClientData clientdata);
void DqeVh_FilterAddHandler(void *ctx, short priority, DqeVh_Callback *callback, ClientData clientdata);

int DqeVh_Url2File(void *ctx, Ns_DString *ds, char *domain, char *url);
void *DqeVh_Ctx(char *server);

#endif
