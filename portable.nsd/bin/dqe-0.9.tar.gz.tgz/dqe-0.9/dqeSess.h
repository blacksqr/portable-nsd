#ifndef DQESESS_H
#define DQESESS_H 1

#include "dqe.h"

/* session Id */
struct dqe_SessId {
    unsigned long sec;
    unsigned long usec;
    unsigned short pid;
    unsigned short tid;
};
#define DQE_SESSID_SIZE             (sizeof(struct dqe_SessId))
#define DQE_SESSID_ENSIZE           (((DQE_SESSID_SIZE+2)/3)*4)
#define DQE_SESSID_KEYSIZE          ((DQE_SESSID_SIZE+(sizeof(int)-1))/sizeof(int))

/* session cookie */
#define DQE_SESSION_COOKIEPREFIX    "dqesess="
#define DQE_SESSION_COOKIESTRLEN    8

/* OpCtx */
struct dqe_Sess_OpCtx {
    Ns_Cache *sessions;
    Ns_ThreadLocalStorage connlocal;
    int maxcachesize;
    int sessionfileexpiration;
    char *sessiondir;
    Ns_Mutex mutex;
};

struct dqe_Sess_Tls {
    struct dqe_Sess_CacheEntry *entry;
    char tclset[64];
    Tcl_Interp *interp;
    int locked;
};

struct dqe_Sess_CacheEntry {
    Ns_Set *keys;
    Ns_Mutex mutex;
    struct dqe_SessId sid;
    char sid64[DQE_SESSID_ENSIZE+1];
    int refcount;
    struct dqe_Sess_OpCtx *oc;
};

/* default config */

/* default session storage directory - important: create the directory! */
#define DQE_SESS_DEFAULT_DIRECTORY      "/usr/local/aolserver/dqe/sessions"
/* default cache size - this is the number of sessions to store in memory */
#define DQE_SESS_DEFAULT_CACHESIZE      1000
/* expiration time for sessions (in the sessions directory) */
#define DQE_SESS_DEFAULT_EXPIRATION     (86400*14)      

#endif
