#ifndef DQECHAN_H
#define DQECHAN_H 1

#include "dqe.h"

struct dqe_Chan_OpCtx {
    int dummy;
};

#endif
