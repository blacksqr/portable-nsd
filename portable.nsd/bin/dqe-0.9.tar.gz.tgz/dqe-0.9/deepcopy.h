#ifndef DEEPCOPY_H
#define DEEPCOPY_H 1

#include <tcl.h>

void *Dc_GetTclObj(Tcl_Obj *obj);
Tcl_Obj *Dc_NewTclObj(void *ptr);
void Dc_FreeDcObj(void *ptr);
unsigned long Dc_ObjSize(void *ptr);

#endif

